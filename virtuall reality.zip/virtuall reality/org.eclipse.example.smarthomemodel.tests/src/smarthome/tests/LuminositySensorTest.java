/**
 */
package smarthome.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import smarthome.LuminositySensor;
import smarthome.SmarthomeFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Luminosity Sensor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link smarthome.LuminositySensor#Luminosity_value_OUT() <em>Luminosity value OUT</em>}</li>
 *   <li>{@link smarthome.LuminositySensor#Luminosity_value_IN() <em>Luminosity value IN</em>}</li>
 *   <li>{@link smarthome.LuminositySensor#WhichState() <em>Which State</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public class LuminositySensorTest extends TestCase {

	/**
	 * The fixture for this Luminosity Sensor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LuminositySensor fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(LuminositySensorTest.class);
	}

	/**
	 * Constructs a new Luminosity Sensor test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LuminositySensorTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Luminosity Sensor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(LuminositySensor fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Luminosity Sensor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LuminositySensor getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(SmarthomeFactory.eINSTANCE.createLuminositySensor());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

	/**
	 * Tests the '{@link smarthome.LuminositySensor#Luminosity_value_OUT() <em>Luminosity value OUT</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smarthome.LuminositySensor#Luminosity_value_OUT()
	 * @generated
	 */
	public void testLuminosity_value_OUT() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link smarthome.LuminositySensor#Luminosity_value_IN() <em>Luminosity value IN</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smarthome.LuminositySensor#Luminosity_value_IN()
	 * @generated
	 */
	public void testLuminosity_value_IN() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link smarthome.LuminositySensor#WhichState() <em>Which State</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smarthome.LuminositySensor#WhichState()
	 * @generated
	 */
	public void testWhichState() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //LuminositySensorTest
