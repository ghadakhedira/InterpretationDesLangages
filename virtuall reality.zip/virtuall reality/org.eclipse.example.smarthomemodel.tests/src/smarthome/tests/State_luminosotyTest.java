/**
 */
package smarthome.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import smarthome.SmarthomeFactory;
import smarthome.State_luminosoty;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>State luminosoty</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class State_luminosotyTest extends TestCase {

	/**
	 * The fixture for this State luminosoty test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected State_luminosoty fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(State_luminosotyTest.class);
	}

	/**
	 * Constructs a new State luminosoty test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public State_luminosotyTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this State luminosoty test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(State_luminosoty fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this State luminosoty test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected State_luminosoty getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(SmarthomeFactory.eINSTANCE.createState_luminosoty());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //State_luminosotyTest
