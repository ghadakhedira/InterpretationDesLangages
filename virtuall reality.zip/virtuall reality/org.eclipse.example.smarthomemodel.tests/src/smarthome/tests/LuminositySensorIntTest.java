/**
 */
package smarthome.tests;

import junit.textui.TestRunner;

import smarthome.LuminositySensorInt;
import smarthome.SmarthomeFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Luminosity Sensor Int</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class LuminositySensorIntTest extends SensorTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(LuminositySensorIntTest.class);
	}

	/**
	 * Constructs a new Luminosity Sensor Int test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LuminositySensorIntTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Luminosity Sensor Int test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected LuminositySensorInt getFixture() {
		return (LuminositySensorInt)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(SmarthomeFactory.eINSTANCE.createLuminositySensorInt());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //LuminositySensorIntTest
