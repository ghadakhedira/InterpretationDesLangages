package org.xtext.example.mydsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.mydsl.services.MyDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Action'", "'{'", "'actuator'", "'}'", "'Actuator'", "'actuator_name'", "'state'", "'-'", "'Shutter'", "'rules'", "'Lamp'", "'Condition'", "'operation'", "'value'", "'sensor'", "'Sensor'", "'sensor_name'", "'type'", "'LuminositySensorInt'", "'LuminositySensorExt'", "'inf'", "'sup'", "'diff'", "'egal'"
    };
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__33=33;
    public static final int T__12=12;
    public static final int T__34=34;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalMyDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyDsl.g"; }



     	private MyDslGrammarAccess grammarAccess;

        public InternalMyDslParser(TokenStream input, MyDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Action";
       	}

       	@Override
       	protected MyDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleAction"
    // InternalMyDsl.g:65:1: entryRuleAction returns [EObject current=null] : iv_ruleAction= ruleAction EOF ;
    public final EObject entryRuleAction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAction = null;


        try {
            // InternalMyDsl.g:65:47: (iv_ruleAction= ruleAction EOF )
            // InternalMyDsl.g:66:2: iv_ruleAction= ruleAction EOF
            {
             newCompositeNode(grammarAccess.getActionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAction=ruleAction();

            state._fsp--;

             current =iv_ruleAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAction"


    // $ANTLR start "ruleAction"
    // InternalMyDsl.g:72:1: ruleAction returns [EObject current=null] : ( () otherlv_1= 'Action' otherlv_2= '{' (otherlv_3= 'actuator' ( ( ruleEString ) ) )? otherlv_5= '}' ) ;
    public final EObject ruleAction() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;


        	enterRule();

        try {
            // InternalMyDsl.g:78:2: ( ( () otherlv_1= 'Action' otherlv_2= '{' (otherlv_3= 'actuator' ( ( ruleEString ) ) )? otherlv_5= '}' ) )
            // InternalMyDsl.g:79:2: ( () otherlv_1= 'Action' otherlv_2= '{' (otherlv_3= 'actuator' ( ( ruleEString ) ) )? otherlv_5= '}' )
            {
            // InternalMyDsl.g:79:2: ( () otherlv_1= 'Action' otherlv_2= '{' (otherlv_3= 'actuator' ( ( ruleEString ) ) )? otherlv_5= '}' )
            // InternalMyDsl.g:80:3: () otherlv_1= 'Action' otherlv_2= '{' (otherlv_3= 'actuator' ( ( ruleEString ) ) )? otherlv_5= '}'
            {
            // InternalMyDsl.g:80:3: ()
            // InternalMyDsl.g:81:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getActionAccess().getActionAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getActionAccess().getActionKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_4); 

            			newLeafNode(otherlv_2, grammarAccess.getActionAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMyDsl.g:95:3: (otherlv_3= 'actuator' ( ( ruleEString ) ) )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==13) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalMyDsl.g:96:4: otherlv_3= 'actuator' ( ( ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,13,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getActionAccess().getActuatorKeyword_3_0());
                    			
                    // InternalMyDsl.g:100:4: ( ( ruleEString ) )
                    // InternalMyDsl.g:101:5: ( ruleEString )
                    {
                    // InternalMyDsl.g:101:5: ( ruleEString )
                    // InternalMyDsl.g:102:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getActionRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getActionAccess().getActuatorActuatorCrossReference_3_1_0());
                    					
                    pushFollow(FOLLOW_6);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_5=(Token)match(input,14,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getActionAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAction"


    // $ANTLR start "entryRuleActuator_Impl"
    // InternalMyDsl.g:125:1: entryRuleActuator_Impl returns [EObject current=null] : iv_ruleActuator_Impl= ruleActuator_Impl EOF ;
    public final EObject entryRuleActuator_Impl() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleActuator_Impl = null;


        try {
            // InternalMyDsl.g:125:54: (iv_ruleActuator_Impl= ruleActuator_Impl EOF )
            // InternalMyDsl.g:126:2: iv_ruleActuator_Impl= ruleActuator_Impl EOF
            {
             newCompositeNode(grammarAccess.getActuator_ImplRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleActuator_Impl=ruleActuator_Impl();

            state._fsp--;

             current =iv_ruleActuator_Impl; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleActuator_Impl"


    // $ANTLR start "ruleActuator_Impl"
    // InternalMyDsl.g:132:1: ruleActuator_Impl returns [EObject current=null] : ( () otherlv_1= 'Actuator' otherlv_2= '{' (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? otherlv_7= '}' ) ;
    public final EObject ruleActuator_Impl() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        AntlrDatatypeRuleToken lv_actuator_name_4_0 = null;

        AntlrDatatypeRuleToken lv_state_6_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:138:2: ( ( () otherlv_1= 'Actuator' otherlv_2= '{' (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? otherlv_7= '}' ) )
            // InternalMyDsl.g:139:2: ( () otherlv_1= 'Actuator' otherlv_2= '{' (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? otherlv_7= '}' )
            {
            // InternalMyDsl.g:139:2: ( () otherlv_1= 'Actuator' otherlv_2= '{' (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? otherlv_7= '}' )
            // InternalMyDsl.g:140:3: () otherlv_1= 'Actuator' otherlv_2= '{' (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? otherlv_7= '}'
            {
            // InternalMyDsl.g:140:3: ()
            // InternalMyDsl.g:141:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getActuator_ImplAccess().getActuatorAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,15,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getActuator_ImplAccess().getActuatorKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_7); 

            			newLeafNode(otherlv_2, grammarAccess.getActuator_ImplAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMyDsl.g:155:3: (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==16) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalMyDsl.g:156:4: otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,16,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getActuator_ImplAccess().getActuator_nameKeyword_3_0());
                    			
                    // InternalMyDsl.g:160:4: ( (lv_actuator_name_4_0= ruleEString ) )
                    // InternalMyDsl.g:161:5: (lv_actuator_name_4_0= ruleEString )
                    {
                    // InternalMyDsl.g:161:5: (lv_actuator_name_4_0= ruleEString )
                    // InternalMyDsl.g:162:6: lv_actuator_name_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getActuator_ImplAccess().getActuator_nameEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_8);
                    lv_actuator_name_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getActuator_ImplRule());
                    						}
                    						set(
                    							current,
                    							"actuator_name",
                    							lv_actuator_name_4_0,
                    							"org.xtext.example.mydsl.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:180:3: (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==17) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalMyDsl.g:181:4: otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) )
                    {
                    otherlv_5=(Token)match(input,17,FOLLOW_9); 

                    				newLeafNode(otherlv_5, grammarAccess.getActuator_ImplAccess().getStateKeyword_4_0());
                    			
                    // InternalMyDsl.g:185:4: ( (lv_state_6_0= ruleEInt ) )
                    // InternalMyDsl.g:186:5: (lv_state_6_0= ruleEInt )
                    {
                    // InternalMyDsl.g:186:5: (lv_state_6_0= ruleEInt )
                    // InternalMyDsl.g:187:6: lv_state_6_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getActuator_ImplAccess().getStateEIntParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_state_6_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getActuator_ImplRule());
                    						}
                    						set(
                    							current,
                    							"state",
                    							lv_state_6_0,
                    							"org.xtext.example.mydsl.MyDsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_7=(Token)match(input,14,FOLLOW_2); 

            			newLeafNode(otherlv_7, grammarAccess.getActuator_ImplAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleActuator_Impl"


    // $ANTLR start "entryRuleEString"
    // InternalMyDsl.g:213:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalMyDsl.g:213:47: (iv_ruleEString= ruleEString EOF )
            // InternalMyDsl.g:214:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalMyDsl.g:220:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalMyDsl.g:226:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalMyDsl.g:227:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalMyDsl.g:227:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==RULE_STRING) ) {
                alt4=1;
            }
            else if ( (LA4_0==RULE_ID) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalMyDsl.g:228:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:236:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleEInt"
    // InternalMyDsl.g:247:1: entryRuleEInt returns [String current=null] : iv_ruleEInt= ruleEInt EOF ;
    public final String entryRuleEInt() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEInt = null;


        try {
            // InternalMyDsl.g:247:44: (iv_ruleEInt= ruleEInt EOF )
            // InternalMyDsl.g:248:2: iv_ruleEInt= ruleEInt EOF
            {
             newCompositeNode(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEInt=ruleEInt();

            state._fsp--;

             current =iv_ruleEInt.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalMyDsl.g:254:1: ruleEInt returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? this_INT_1= RULE_INT ) ;
    public final AntlrDatatypeRuleToken ruleEInt() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;


        	enterRule();

        try {
            // InternalMyDsl.g:260:2: ( ( (kw= '-' )? this_INT_1= RULE_INT ) )
            // InternalMyDsl.g:261:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            {
            // InternalMyDsl.g:261:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            // InternalMyDsl.g:262:3: (kw= '-' )? this_INT_1= RULE_INT
            {
            // InternalMyDsl.g:262:3: (kw= '-' )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==18) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalMyDsl.g:263:4: kw= '-'
                    {
                    kw=(Token)match(input,18,FOLLOW_10); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEIntAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            this_INT_1=(Token)match(input,RULE_INT,FOLLOW_2); 

            			current.merge(this_INT_1);
            		

            			newLeafNode(this_INT_1, grammarAccess.getEIntAccess().getINTTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "entryRuleShutter"
    // InternalMyDsl.g:280:1: entryRuleShutter returns [EObject current=null] : iv_ruleShutter= ruleShutter EOF ;
    public final EObject entryRuleShutter() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleShutter = null;


        try {
            // InternalMyDsl.g:280:48: (iv_ruleShutter= ruleShutter EOF )
            // InternalMyDsl.g:281:2: iv_ruleShutter= ruleShutter EOF
            {
             newCompositeNode(grammarAccess.getShutterRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleShutter=ruleShutter();

            state._fsp--;

             current =iv_ruleShutter; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleShutter"


    // $ANTLR start "ruleShutter"
    // InternalMyDsl.g:287:1: ruleShutter returns [EObject current=null] : ( () otherlv_1= 'Shutter' otherlv_2= '{' (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'rules' ( ( ruleEString ) ) )? otherlv_9= '}' ) ;
    public final EObject ruleShutter() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        AntlrDatatypeRuleToken lv_actuator_name_4_0 = null;

        AntlrDatatypeRuleToken lv_state_6_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:293:2: ( ( () otherlv_1= 'Shutter' otherlv_2= '{' (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'rules' ( ( ruleEString ) ) )? otherlv_9= '}' ) )
            // InternalMyDsl.g:294:2: ( () otherlv_1= 'Shutter' otherlv_2= '{' (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'rules' ( ( ruleEString ) ) )? otherlv_9= '}' )
            {
            // InternalMyDsl.g:294:2: ( () otherlv_1= 'Shutter' otherlv_2= '{' (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'rules' ( ( ruleEString ) ) )? otherlv_9= '}' )
            // InternalMyDsl.g:295:3: () otherlv_1= 'Shutter' otherlv_2= '{' (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'rules' ( ( ruleEString ) ) )? otherlv_9= '}'
            {
            // InternalMyDsl.g:295:3: ()
            // InternalMyDsl.g:296:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getShutterAccess().getShutterAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,19,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getShutterAccess().getShutterKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_11); 

            			newLeafNode(otherlv_2, grammarAccess.getShutterAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMyDsl.g:310:3: (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==16) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalMyDsl.g:311:4: otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,16,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getShutterAccess().getActuator_nameKeyword_3_0());
                    			
                    // InternalMyDsl.g:315:4: ( (lv_actuator_name_4_0= ruleEString ) )
                    // InternalMyDsl.g:316:5: (lv_actuator_name_4_0= ruleEString )
                    {
                    // InternalMyDsl.g:316:5: (lv_actuator_name_4_0= ruleEString )
                    // InternalMyDsl.g:317:6: lv_actuator_name_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getShutterAccess().getActuator_nameEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_12);
                    lv_actuator_name_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getShutterRule());
                    						}
                    						set(
                    							current,
                    							"actuator_name",
                    							lv_actuator_name_4_0,
                    							"org.xtext.example.mydsl.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:335:3: (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==17) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalMyDsl.g:336:4: otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) )
                    {
                    otherlv_5=(Token)match(input,17,FOLLOW_9); 

                    				newLeafNode(otherlv_5, grammarAccess.getShutterAccess().getStateKeyword_4_0());
                    			
                    // InternalMyDsl.g:340:4: ( (lv_state_6_0= ruleEInt ) )
                    // InternalMyDsl.g:341:5: (lv_state_6_0= ruleEInt )
                    {
                    // InternalMyDsl.g:341:5: (lv_state_6_0= ruleEInt )
                    // InternalMyDsl.g:342:6: lv_state_6_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getShutterAccess().getStateEIntParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_13);
                    lv_state_6_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getShutterRule());
                    						}
                    						set(
                    							current,
                    							"state",
                    							lv_state_6_0,
                    							"org.xtext.example.mydsl.MyDsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:360:3: (otherlv_7= 'rules' ( ( ruleEString ) ) )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==20) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalMyDsl.g:361:4: otherlv_7= 'rules' ( ( ruleEString ) )
                    {
                    otherlv_7=(Token)match(input,20,FOLLOW_5); 

                    				newLeafNode(otherlv_7, grammarAccess.getShutterAccess().getRulesKeyword_5_0());
                    			
                    // InternalMyDsl.g:365:4: ( ( ruleEString ) )
                    // InternalMyDsl.g:366:5: ( ruleEString )
                    {
                    // InternalMyDsl.g:366:5: ( ruleEString )
                    // InternalMyDsl.g:367:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getShutterRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getShutterAccess().getRulesRuleCrossReference_5_1_0());
                    					
                    pushFollow(FOLLOW_6);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_9=(Token)match(input,14,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getShutterAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleShutter"


    // $ANTLR start "entryRuleLamp"
    // InternalMyDsl.g:390:1: entryRuleLamp returns [EObject current=null] : iv_ruleLamp= ruleLamp EOF ;
    public final EObject entryRuleLamp() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLamp = null;


        try {
            // InternalMyDsl.g:390:45: (iv_ruleLamp= ruleLamp EOF )
            // InternalMyDsl.g:391:2: iv_ruleLamp= ruleLamp EOF
            {
             newCompositeNode(grammarAccess.getLampRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLamp=ruleLamp();

            state._fsp--;

             current =iv_ruleLamp; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLamp"


    // $ANTLR start "ruleLamp"
    // InternalMyDsl.g:397:1: ruleLamp returns [EObject current=null] : ( () otherlv_1= 'Lamp' otherlv_2= '{' (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'rules' ( ( ruleEString ) ) )? otherlv_9= '}' ) ;
    public final EObject ruleLamp() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        AntlrDatatypeRuleToken lv_actuator_name_4_0 = null;

        AntlrDatatypeRuleToken lv_state_6_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:403:2: ( ( () otherlv_1= 'Lamp' otherlv_2= '{' (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'rules' ( ( ruleEString ) ) )? otherlv_9= '}' ) )
            // InternalMyDsl.g:404:2: ( () otherlv_1= 'Lamp' otherlv_2= '{' (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'rules' ( ( ruleEString ) ) )? otherlv_9= '}' )
            {
            // InternalMyDsl.g:404:2: ( () otherlv_1= 'Lamp' otherlv_2= '{' (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'rules' ( ( ruleEString ) ) )? otherlv_9= '}' )
            // InternalMyDsl.g:405:3: () otherlv_1= 'Lamp' otherlv_2= '{' (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'rules' ( ( ruleEString ) ) )? otherlv_9= '}'
            {
            // InternalMyDsl.g:405:3: ()
            // InternalMyDsl.g:406:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getLampAccess().getLampAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,21,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getLampAccess().getLampKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_11); 

            			newLeafNode(otherlv_2, grammarAccess.getLampAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMyDsl.g:420:3: (otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==16) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalMyDsl.g:421:4: otherlv_3= 'actuator_name' ( (lv_actuator_name_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,16,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getLampAccess().getActuator_nameKeyword_3_0());
                    			
                    // InternalMyDsl.g:425:4: ( (lv_actuator_name_4_0= ruleEString ) )
                    // InternalMyDsl.g:426:5: (lv_actuator_name_4_0= ruleEString )
                    {
                    // InternalMyDsl.g:426:5: (lv_actuator_name_4_0= ruleEString )
                    // InternalMyDsl.g:427:6: lv_actuator_name_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getLampAccess().getActuator_nameEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_12);
                    lv_actuator_name_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getLampRule());
                    						}
                    						set(
                    							current,
                    							"actuator_name",
                    							lv_actuator_name_4_0,
                    							"org.xtext.example.mydsl.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:445:3: (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==17) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalMyDsl.g:446:4: otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) )
                    {
                    otherlv_5=(Token)match(input,17,FOLLOW_9); 

                    				newLeafNode(otherlv_5, grammarAccess.getLampAccess().getStateKeyword_4_0());
                    			
                    // InternalMyDsl.g:450:4: ( (lv_state_6_0= ruleEInt ) )
                    // InternalMyDsl.g:451:5: (lv_state_6_0= ruleEInt )
                    {
                    // InternalMyDsl.g:451:5: (lv_state_6_0= ruleEInt )
                    // InternalMyDsl.g:452:6: lv_state_6_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getLampAccess().getStateEIntParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_13);
                    lv_state_6_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getLampRule());
                    						}
                    						set(
                    							current,
                    							"state",
                    							lv_state_6_0,
                    							"org.xtext.example.mydsl.MyDsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:470:3: (otherlv_7= 'rules' ( ( ruleEString ) ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==20) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalMyDsl.g:471:4: otherlv_7= 'rules' ( ( ruleEString ) )
                    {
                    otherlv_7=(Token)match(input,20,FOLLOW_5); 

                    				newLeafNode(otherlv_7, grammarAccess.getLampAccess().getRulesKeyword_5_0());
                    			
                    // InternalMyDsl.g:475:4: ( ( ruleEString ) )
                    // InternalMyDsl.g:476:5: ( ruleEString )
                    {
                    // InternalMyDsl.g:476:5: ( ruleEString )
                    // InternalMyDsl.g:477:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getLampRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getLampAccess().getRulesRuleCrossReference_5_1_0());
                    					
                    pushFollow(FOLLOW_6);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_9=(Token)match(input,14,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getLampAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLamp"


    // $ANTLR start "entryRuleCondition"
    // InternalMyDsl.g:500:1: entryRuleCondition returns [EObject current=null] : iv_ruleCondition= ruleCondition EOF ;
    public final EObject entryRuleCondition() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCondition = null;


        try {
            // InternalMyDsl.g:500:50: (iv_ruleCondition= ruleCondition EOF )
            // InternalMyDsl.g:501:2: iv_ruleCondition= ruleCondition EOF
            {
             newCompositeNode(grammarAccess.getConditionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCondition=ruleCondition();

            state._fsp--;

             current =iv_ruleCondition; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCondition"


    // $ANTLR start "ruleCondition"
    // InternalMyDsl.g:507:1: ruleCondition returns [EObject current=null] : ( () otherlv_1= 'Condition' otherlv_2= '{' (otherlv_3= 'operation' ( (lv_operation_4_0= ruleOPcomp ) ) )? (otherlv_5= 'value' ( (lv_value_6_0= ruleEInt ) ) )? (otherlv_7= 'sensor' ( ( ruleEString ) ) )? otherlv_9= '}' ) ;
    public final EObject ruleCondition() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Enumerator lv_operation_4_0 = null;

        AntlrDatatypeRuleToken lv_value_6_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:513:2: ( ( () otherlv_1= 'Condition' otherlv_2= '{' (otherlv_3= 'operation' ( (lv_operation_4_0= ruleOPcomp ) ) )? (otherlv_5= 'value' ( (lv_value_6_0= ruleEInt ) ) )? (otherlv_7= 'sensor' ( ( ruleEString ) ) )? otherlv_9= '}' ) )
            // InternalMyDsl.g:514:2: ( () otherlv_1= 'Condition' otherlv_2= '{' (otherlv_3= 'operation' ( (lv_operation_4_0= ruleOPcomp ) ) )? (otherlv_5= 'value' ( (lv_value_6_0= ruleEInt ) ) )? (otherlv_7= 'sensor' ( ( ruleEString ) ) )? otherlv_9= '}' )
            {
            // InternalMyDsl.g:514:2: ( () otherlv_1= 'Condition' otherlv_2= '{' (otherlv_3= 'operation' ( (lv_operation_4_0= ruleOPcomp ) ) )? (otherlv_5= 'value' ( (lv_value_6_0= ruleEInt ) ) )? (otherlv_7= 'sensor' ( ( ruleEString ) ) )? otherlv_9= '}' )
            // InternalMyDsl.g:515:3: () otherlv_1= 'Condition' otherlv_2= '{' (otherlv_3= 'operation' ( (lv_operation_4_0= ruleOPcomp ) ) )? (otherlv_5= 'value' ( (lv_value_6_0= ruleEInt ) ) )? (otherlv_7= 'sensor' ( ( ruleEString ) ) )? otherlv_9= '}'
            {
            // InternalMyDsl.g:515:3: ()
            // InternalMyDsl.g:516:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getConditionAccess().getConditionAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,22,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getConditionAccess().getConditionKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_14); 

            			newLeafNode(otherlv_2, grammarAccess.getConditionAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMyDsl.g:530:3: (otherlv_3= 'operation' ( (lv_operation_4_0= ruleOPcomp ) ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==23) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalMyDsl.g:531:4: otherlv_3= 'operation' ( (lv_operation_4_0= ruleOPcomp ) )
                    {
                    otherlv_3=(Token)match(input,23,FOLLOW_15); 

                    				newLeafNode(otherlv_3, grammarAccess.getConditionAccess().getOperationKeyword_3_0());
                    			
                    // InternalMyDsl.g:535:4: ( (lv_operation_4_0= ruleOPcomp ) )
                    // InternalMyDsl.g:536:5: (lv_operation_4_0= ruleOPcomp )
                    {
                    // InternalMyDsl.g:536:5: (lv_operation_4_0= ruleOPcomp )
                    // InternalMyDsl.g:537:6: lv_operation_4_0= ruleOPcomp
                    {

                    						newCompositeNode(grammarAccess.getConditionAccess().getOperationOPcompEnumRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_16);
                    lv_operation_4_0=ruleOPcomp();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getConditionRule());
                    						}
                    						set(
                    							current,
                    							"operation",
                    							lv_operation_4_0,
                    							"org.xtext.example.mydsl.MyDsl.OPcomp");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:555:3: (otherlv_5= 'value' ( (lv_value_6_0= ruleEInt ) ) )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==24) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalMyDsl.g:556:4: otherlv_5= 'value' ( (lv_value_6_0= ruleEInt ) )
                    {
                    otherlv_5=(Token)match(input,24,FOLLOW_9); 

                    				newLeafNode(otherlv_5, grammarAccess.getConditionAccess().getValueKeyword_4_0());
                    			
                    // InternalMyDsl.g:560:4: ( (lv_value_6_0= ruleEInt ) )
                    // InternalMyDsl.g:561:5: (lv_value_6_0= ruleEInt )
                    {
                    // InternalMyDsl.g:561:5: (lv_value_6_0= ruleEInt )
                    // InternalMyDsl.g:562:6: lv_value_6_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getConditionAccess().getValueEIntParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_17);
                    lv_value_6_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getConditionRule());
                    						}
                    						set(
                    							current,
                    							"value",
                    							lv_value_6_0,
                    							"org.xtext.example.mydsl.MyDsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:580:3: (otherlv_7= 'sensor' ( ( ruleEString ) ) )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==25) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalMyDsl.g:581:4: otherlv_7= 'sensor' ( ( ruleEString ) )
                    {
                    otherlv_7=(Token)match(input,25,FOLLOW_5); 

                    				newLeafNode(otherlv_7, grammarAccess.getConditionAccess().getSensorKeyword_5_0());
                    			
                    // InternalMyDsl.g:585:4: ( ( ruleEString ) )
                    // InternalMyDsl.g:586:5: ( ruleEString )
                    {
                    // InternalMyDsl.g:586:5: ( ruleEString )
                    // InternalMyDsl.g:587:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getConditionRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getConditionAccess().getSensorSensorCrossReference_5_1_0());
                    					
                    pushFollow(FOLLOW_6);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_9=(Token)match(input,14,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getConditionAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCondition"


    // $ANTLR start "entryRuleSensor_Impl"
    // InternalMyDsl.g:610:1: entryRuleSensor_Impl returns [EObject current=null] : iv_ruleSensor_Impl= ruleSensor_Impl EOF ;
    public final EObject entryRuleSensor_Impl() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSensor_Impl = null;


        try {
            // InternalMyDsl.g:610:52: (iv_ruleSensor_Impl= ruleSensor_Impl EOF )
            // InternalMyDsl.g:611:2: iv_ruleSensor_Impl= ruleSensor_Impl EOF
            {
             newCompositeNode(grammarAccess.getSensor_ImplRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSensor_Impl=ruleSensor_Impl();

            state._fsp--;

             current =iv_ruleSensor_Impl; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSensor_Impl"


    // $ANTLR start "ruleSensor_Impl"
    // InternalMyDsl.g:617:1: ruleSensor_Impl returns [EObject current=null] : ( () otherlv_1= 'Sensor' otherlv_2= '{' (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? otherlv_9= '}' ) ;
    public final EObject ruleSensor_Impl() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        AntlrDatatypeRuleToken lv_sensor_name_4_0 = null;

        AntlrDatatypeRuleToken lv_state_6_0 = null;

        AntlrDatatypeRuleToken lv_type_8_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:623:2: ( ( () otherlv_1= 'Sensor' otherlv_2= '{' (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? otherlv_9= '}' ) )
            // InternalMyDsl.g:624:2: ( () otherlv_1= 'Sensor' otherlv_2= '{' (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? otherlv_9= '}' )
            {
            // InternalMyDsl.g:624:2: ( () otherlv_1= 'Sensor' otherlv_2= '{' (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? otherlv_9= '}' )
            // InternalMyDsl.g:625:3: () otherlv_1= 'Sensor' otherlv_2= '{' (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? otherlv_9= '}'
            {
            // InternalMyDsl.g:625:3: ()
            // InternalMyDsl.g:626:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getSensor_ImplAccess().getSensorAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,26,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getSensor_ImplAccess().getSensorKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_18); 

            			newLeafNode(otherlv_2, grammarAccess.getSensor_ImplAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMyDsl.g:640:3: (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==27) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalMyDsl.g:641:4: otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,27,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getSensor_ImplAccess().getSensor_nameKeyword_3_0());
                    			
                    // InternalMyDsl.g:645:4: ( (lv_sensor_name_4_0= ruleEString ) )
                    // InternalMyDsl.g:646:5: (lv_sensor_name_4_0= ruleEString )
                    {
                    // InternalMyDsl.g:646:5: (lv_sensor_name_4_0= ruleEString )
                    // InternalMyDsl.g:647:6: lv_sensor_name_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getSensor_ImplAccess().getSensor_nameEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_19);
                    lv_sensor_name_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSensor_ImplRule());
                    						}
                    						set(
                    							current,
                    							"sensor_name",
                    							lv_sensor_name_4_0,
                    							"org.xtext.example.mydsl.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:665:3: (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==17) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalMyDsl.g:666:4: otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) )
                    {
                    otherlv_5=(Token)match(input,17,FOLLOW_9); 

                    				newLeafNode(otherlv_5, grammarAccess.getSensor_ImplAccess().getStateKeyword_4_0());
                    			
                    // InternalMyDsl.g:670:4: ( (lv_state_6_0= ruleEInt ) )
                    // InternalMyDsl.g:671:5: (lv_state_6_0= ruleEInt )
                    {
                    // InternalMyDsl.g:671:5: (lv_state_6_0= ruleEInt )
                    // InternalMyDsl.g:672:6: lv_state_6_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getSensor_ImplAccess().getStateEIntParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_20);
                    lv_state_6_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSensor_ImplRule());
                    						}
                    						set(
                    							current,
                    							"state",
                    							lv_state_6_0,
                    							"org.xtext.example.mydsl.MyDsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:690:3: (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==28) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalMyDsl.g:691:4: otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) )
                    {
                    otherlv_7=(Token)match(input,28,FOLLOW_5); 

                    				newLeafNode(otherlv_7, grammarAccess.getSensor_ImplAccess().getTypeKeyword_5_0());
                    			
                    // InternalMyDsl.g:695:4: ( (lv_type_8_0= ruleEString ) )
                    // InternalMyDsl.g:696:5: (lv_type_8_0= ruleEString )
                    {
                    // InternalMyDsl.g:696:5: (lv_type_8_0= ruleEString )
                    // InternalMyDsl.g:697:6: lv_type_8_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getSensor_ImplAccess().getTypeEStringParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_type_8_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSensor_ImplRule());
                    						}
                    						set(
                    							current,
                    							"type",
                    							lv_type_8_0,
                    							"org.xtext.example.mydsl.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_9=(Token)match(input,14,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getSensor_ImplAccess().getRightCurlyBracketKeyword_6());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSensor_Impl"


    // $ANTLR start "entryRuleLuminositySensorInt"
    // InternalMyDsl.g:723:1: entryRuleLuminositySensorInt returns [EObject current=null] : iv_ruleLuminositySensorInt= ruleLuminositySensorInt EOF ;
    public final EObject entryRuleLuminositySensorInt() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLuminositySensorInt = null;


        try {
            // InternalMyDsl.g:723:60: (iv_ruleLuminositySensorInt= ruleLuminositySensorInt EOF )
            // InternalMyDsl.g:724:2: iv_ruleLuminositySensorInt= ruleLuminositySensorInt EOF
            {
             newCompositeNode(grammarAccess.getLuminositySensorIntRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLuminositySensorInt=ruleLuminositySensorInt();

            state._fsp--;

             current =iv_ruleLuminositySensorInt; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLuminositySensorInt"


    // $ANTLR start "ruleLuminositySensorInt"
    // InternalMyDsl.g:730:1: ruleLuminositySensorInt returns [EObject current=null] : ( () otherlv_1= 'LuminositySensorInt' otherlv_2= '{' (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'rules' ( ( ruleEString ) ) )? otherlv_11= '}' ) ;
    public final EObject ruleLuminositySensorInt() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        AntlrDatatypeRuleToken lv_sensor_name_4_0 = null;

        AntlrDatatypeRuleToken lv_state_6_0 = null;

        AntlrDatatypeRuleToken lv_type_8_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:736:2: ( ( () otherlv_1= 'LuminositySensorInt' otherlv_2= '{' (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'rules' ( ( ruleEString ) ) )? otherlv_11= '}' ) )
            // InternalMyDsl.g:737:2: ( () otherlv_1= 'LuminositySensorInt' otherlv_2= '{' (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'rules' ( ( ruleEString ) ) )? otherlv_11= '}' )
            {
            // InternalMyDsl.g:737:2: ( () otherlv_1= 'LuminositySensorInt' otherlv_2= '{' (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'rules' ( ( ruleEString ) ) )? otherlv_11= '}' )
            // InternalMyDsl.g:738:3: () otherlv_1= 'LuminositySensorInt' otherlv_2= '{' (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'rules' ( ( ruleEString ) ) )? otherlv_11= '}'
            {
            // InternalMyDsl.g:738:3: ()
            // InternalMyDsl.g:739:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getLuminositySensorIntAccess().getLuminositySensorIntAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,29,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getLuminositySensorIntAccess().getLuminositySensorIntKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_21); 

            			newLeafNode(otherlv_2, grammarAccess.getLuminositySensorIntAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMyDsl.g:753:3: (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==27) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalMyDsl.g:754:4: otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,27,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getLuminositySensorIntAccess().getSensor_nameKeyword_3_0());
                    			
                    // InternalMyDsl.g:758:4: ( (lv_sensor_name_4_0= ruleEString ) )
                    // InternalMyDsl.g:759:5: (lv_sensor_name_4_0= ruleEString )
                    {
                    // InternalMyDsl.g:759:5: (lv_sensor_name_4_0= ruleEString )
                    // InternalMyDsl.g:760:6: lv_sensor_name_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getLuminositySensorIntAccess().getSensor_nameEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_22);
                    lv_sensor_name_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getLuminositySensorIntRule());
                    						}
                    						set(
                    							current,
                    							"sensor_name",
                    							lv_sensor_name_4_0,
                    							"org.xtext.example.mydsl.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:778:3: (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==17) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalMyDsl.g:779:4: otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) )
                    {
                    otherlv_5=(Token)match(input,17,FOLLOW_9); 

                    				newLeafNode(otherlv_5, grammarAccess.getLuminositySensorIntAccess().getStateKeyword_4_0());
                    			
                    // InternalMyDsl.g:783:4: ( (lv_state_6_0= ruleEInt ) )
                    // InternalMyDsl.g:784:5: (lv_state_6_0= ruleEInt )
                    {
                    // InternalMyDsl.g:784:5: (lv_state_6_0= ruleEInt )
                    // InternalMyDsl.g:785:6: lv_state_6_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getLuminositySensorIntAccess().getStateEIntParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_23);
                    lv_state_6_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getLuminositySensorIntRule());
                    						}
                    						set(
                    							current,
                    							"state",
                    							lv_state_6_0,
                    							"org.xtext.example.mydsl.MyDsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:803:3: (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==28) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalMyDsl.g:804:4: otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) )
                    {
                    otherlv_7=(Token)match(input,28,FOLLOW_5); 

                    				newLeafNode(otherlv_7, grammarAccess.getLuminositySensorIntAccess().getTypeKeyword_5_0());
                    			
                    // InternalMyDsl.g:808:4: ( (lv_type_8_0= ruleEString ) )
                    // InternalMyDsl.g:809:5: (lv_type_8_0= ruleEString )
                    {
                    // InternalMyDsl.g:809:5: (lv_type_8_0= ruleEString )
                    // InternalMyDsl.g:810:6: lv_type_8_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getLuminositySensorIntAccess().getTypeEStringParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_13);
                    lv_type_8_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getLuminositySensorIntRule());
                    						}
                    						set(
                    							current,
                    							"type",
                    							lv_type_8_0,
                    							"org.xtext.example.mydsl.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:828:3: (otherlv_9= 'rules' ( ( ruleEString ) ) )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==20) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // InternalMyDsl.g:829:4: otherlv_9= 'rules' ( ( ruleEString ) )
                    {
                    otherlv_9=(Token)match(input,20,FOLLOW_5); 

                    				newLeafNode(otherlv_9, grammarAccess.getLuminositySensorIntAccess().getRulesKeyword_6_0());
                    			
                    // InternalMyDsl.g:833:4: ( ( ruleEString ) )
                    // InternalMyDsl.g:834:5: ( ruleEString )
                    {
                    // InternalMyDsl.g:834:5: ( ruleEString )
                    // InternalMyDsl.g:835:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getLuminositySensorIntRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getLuminositySensorIntAccess().getRulesRuleCrossReference_6_1_0());
                    					
                    pushFollow(FOLLOW_6);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_11=(Token)match(input,14,FOLLOW_2); 

            			newLeafNode(otherlv_11, grammarAccess.getLuminositySensorIntAccess().getRightCurlyBracketKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLuminositySensorInt"


    // $ANTLR start "entryRuleLuminositySensorExt"
    // InternalMyDsl.g:858:1: entryRuleLuminositySensorExt returns [EObject current=null] : iv_ruleLuminositySensorExt= ruleLuminositySensorExt EOF ;
    public final EObject entryRuleLuminositySensorExt() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleLuminositySensorExt = null;


        try {
            // InternalMyDsl.g:858:60: (iv_ruleLuminositySensorExt= ruleLuminositySensorExt EOF )
            // InternalMyDsl.g:859:2: iv_ruleLuminositySensorExt= ruleLuminositySensorExt EOF
            {
             newCompositeNode(grammarAccess.getLuminositySensorExtRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleLuminositySensorExt=ruleLuminositySensorExt();

            state._fsp--;

             current =iv_ruleLuminositySensorExt; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleLuminositySensorExt"


    // $ANTLR start "ruleLuminositySensorExt"
    // InternalMyDsl.g:865:1: ruleLuminositySensorExt returns [EObject current=null] : ( () otherlv_1= 'LuminositySensorExt' otherlv_2= '{' (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'rules' ( ( ruleEString ) ) )? otherlv_11= '}' ) ;
    public final EObject ruleLuminositySensorExt() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        AntlrDatatypeRuleToken lv_sensor_name_4_0 = null;

        AntlrDatatypeRuleToken lv_state_6_0 = null;

        AntlrDatatypeRuleToken lv_type_8_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:871:2: ( ( () otherlv_1= 'LuminositySensorExt' otherlv_2= '{' (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'rules' ( ( ruleEString ) ) )? otherlv_11= '}' ) )
            // InternalMyDsl.g:872:2: ( () otherlv_1= 'LuminositySensorExt' otherlv_2= '{' (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'rules' ( ( ruleEString ) ) )? otherlv_11= '}' )
            {
            // InternalMyDsl.g:872:2: ( () otherlv_1= 'LuminositySensorExt' otherlv_2= '{' (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'rules' ( ( ruleEString ) ) )? otherlv_11= '}' )
            // InternalMyDsl.g:873:3: () otherlv_1= 'LuminositySensorExt' otherlv_2= '{' (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )? (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )? (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )? (otherlv_9= 'rules' ( ( ruleEString ) ) )? otherlv_11= '}'
            {
            // InternalMyDsl.g:873:3: ()
            // InternalMyDsl.g:874:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getLuminositySensorExtAccess().getLuminositySensorExtAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,30,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getLuminositySensorExtAccess().getLuminositySensorExtKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_21); 

            			newLeafNode(otherlv_2, grammarAccess.getLuminositySensorExtAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMyDsl.g:888:3: (otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) ) )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==27) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalMyDsl.g:889:4: otherlv_3= 'sensor_name' ( (lv_sensor_name_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,27,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getLuminositySensorExtAccess().getSensor_nameKeyword_3_0());
                    			
                    // InternalMyDsl.g:893:4: ( (lv_sensor_name_4_0= ruleEString ) )
                    // InternalMyDsl.g:894:5: (lv_sensor_name_4_0= ruleEString )
                    {
                    // InternalMyDsl.g:894:5: (lv_sensor_name_4_0= ruleEString )
                    // InternalMyDsl.g:895:6: lv_sensor_name_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getLuminositySensorExtAccess().getSensor_nameEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_22);
                    lv_sensor_name_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getLuminositySensorExtRule());
                    						}
                    						set(
                    							current,
                    							"sensor_name",
                    							lv_sensor_name_4_0,
                    							"org.xtext.example.mydsl.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:913:3: (otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) ) )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==17) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalMyDsl.g:914:4: otherlv_5= 'state' ( (lv_state_6_0= ruleEInt ) )
                    {
                    otherlv_5=(Token)match(input,17,FOLLOW_9); 

                    				newLeafNode(otherlv_5, grammarAccess.getLuminositySensorExtAccess().getStateKeyword_4_0());
                    			
                    // InternalMyDsl.g:918:4: ( (lv_state_6_0= ruleEInt ) )
                    // InternalMyDsl.g:919:5: (lv_state_6_0= ruleEInt )
                    {
                    // InternalMyDsl.g:919:5: (lv_state_6_0= ruleEInt )
                    // InternalMyDsl.g:920:6: lv_state_6_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getLuminositySensorExtAccess().getStateEIntParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_23);
                    lv_state_6_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getLuminositySensorExtRule());
                    						}
                    						set(
                    							current,
                    							"state",
                    							lv_state_6_0,
                    							"org.xtext.example.mydsl.MyDsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:938:3: (otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) ) )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==28) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // InternalMyDsl.g:939:4: otherlv_7= 'type' ( (lv_type_8_0= ruleEString ) )
                    {
                    otherlv_7=(Token)match(input,28,FOLLOW_5); 

                    				newLeafNode(otherlv_7, grammarAccess.getLuminositySensorExtAccess().getTypeKeyword_5_0());
                    			
                    // InternalMyDsl.g:943:4: ( (lv_type_8_0= ruleEString ) )
                    // InternalMyDsl.g:944:5: (lv_type_8_0= ruleEString )
                    {
                    // InternalMyDsl.g:944:5: (lv_type_8_0= ruleEString )
                    // InternalMyDsl.g:945:6: lv_type_8_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getLuminositySensorExtAccess().getTypeEStringParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_13);
                    lv_type_8_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getLuminositySensorExtRule());
                    						}
                    						set(
                    							current,
                    							"type",
                    							lv_type_8_0,
                    							"org.xtext.example.mydsl.MyDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMyDsl.g:963:3: (otherlv_9= 'rules' ( ( ruleEString ) ) )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==20) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalMyDsl.g:964:4: otherlv_9= 'rules' ( ( ruleEString ) )
                    {
                    otherlv_9=(Token)match(input,20,FOLLOW_5); 

                    				newLeafNode(otherlv_9, grammarAccess.getLuminositySensorExtAccess().getRulesKeyword_6_0());
                    			
                    // InternalMyDsl.g:968:4: ( ( ruleEString ) )
                    // InternalMyDsl.g:969:5: ( ruleEString )
                    {
                    // InternalMyDsl.g:969:5: ( ruleEString )
                    // InternalMyDsl.g:970:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getLuminositySensorExtRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getLuminositySensorExtAccess().getRulesRuleCrossReference_6_1_0());
                    					
                    pushFollow(FOLLOW_6);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_11=(Token)match(input,14,FOLLOW_2); 

            			newLeafNode(otherlv_11, grammarAccess.getLuminositySensorExtAccess().getRightCurlyBracketKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleLuminositySensorExt"


    // $ANTLR start "ruleOPcomp"
    // InternalMyDsl.g:993:1: ruleOPcomp returns [Enumerator current=null] : ( (enumLiteral_0= 'inf' ) | (enumLiteral_1= 'sup' ) | (enumLiteral_2= 'diff' ) | (enumLiteral_3= 'egal' ) ) ;
    public final Enumerator ruleOPcomp() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;


        	enterRule();

        try {
            // InternalMyDsl.g:999:2: ( ( (enumLiteral_0= 'inf' ) | (enumLiteral_1= 'sup' ) | (enumLiteral_2= 'diff' ) | (enumLiteral_3= 'egal' ) ) )
            // InternalMyDsl.g:1000:2: ( (enumLiteral_0= 'inf' ) | (enumLiteral_1= 'sup' ) | (enumLiteral_2= 'diff' ) | (enumLiteral_3= 'egal' ) )
            {
            // InternalMyDsl.g:1000:2: ( (enumLiteral_0= 'inf' ) | (enumLiteral_1= 'sup' ) | (enumLiteral_2= 'diff' ) | (enumLiteral_3= 'egal' ) )
            int alt26=4;
            switch ( input.LA(1) ) {
            case 31:
                {
                alt26=1;
                }
                break;
            case 32:
                {
                alt26=2;
                }
                break;
            case 33:
                {
                alt26=3;
                }
                break;
            case 34:
                {
                alt26=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 26, 0, input);

                throw nvae;
            }

            switch (alt26) {
                case 1 :
                    // InternalMyDsl.g:1001:3: (enumLiteral_0= 'inf' )
                    {
                    // InternalMyDsl.g:1001:3: (enumLiteral_0= 'inf' )
                    // InternalMyDsl.g:1002:4: enumLiteral_0= 'inf'
                    {
                    enumLiteral_0=(Token)match(input,31,FOLLOW_2); 

                    				current = grammarAccess.getOPcompAccess().getInfEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getOPcompAccess().getInfEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:1009:3: (enumLiteral_1= 'sup' )
                    {
                    // InternalMyDsl.g:1009:3: (enumLiteral_1= 'sup' )
                    // InternalMyDsl.g:1010:4: enumLiteral_1= 'sup'
                    {
                    enumLiteral_1=(Token)match(input,32,FOLLOW_2); 

                    				current = grammarAccess.getOPcompAccess().getSupEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getOPcompAccess().getSupEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:1017:3: (enumLiteral_2= 'diff' )
                    {
                    // InternalMyDsl.g:1017:3: (enumLiteral_2= 'diff' )
                    // InternalMyDsl.g:1018:4: enumLiteral_2= 'diff'
                    {
                    enumLiteral_2=(Token)match(input,33,FOLLOW_2); 

                    				current = grammarAccess.getOPcompAccess().getDiffEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getOPcompAccess().getDiffEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:1025:3: (enumLiteral_3= 'egal' )
                    {
                    // InternalMyDsl.g:1025:3: (enumLiteral_3= 'egal' )
                    // InternalMyDsl.g:1026:4: enumLiteral_3= 'egal'
                    {
                    enumLiteral_3=(Token)match(input,34,FOLLOW_2); 

                    				current = grammarAccess.getOPcompAccess().getEgalEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getOPcompAccess().getEgalEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOPcomp"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000006000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000034000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000024000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000040040L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000134000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000124000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000104000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000003804000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000780000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000003004000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000002004000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000018024000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000010024000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000010004000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000018124000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000010124000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000010104000L});

}