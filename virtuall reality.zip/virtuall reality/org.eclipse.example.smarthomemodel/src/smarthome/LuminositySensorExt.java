/**
 */
package smarthome;

import org.eclipse.emf.ecore.EObject;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Luminosity Sensor Ext</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smarthome.LuminositySensorExt#getRules <em>Rules</em>}</li>
 *   <li>{@link smarthome.LuminositySensorExt#getOperation <em>Operation</em>}</li>
 * </ul>
 *
 * @see smarthome.SmarthomePackage#getLuminositySensorExt()
 * @model
 * @generated
 */
public interface LuminositySensorExt extends EObject {
	/**
	 * Returns the value of the '<em><b>Rules</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Rules</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rules</em>' reference.
	 * @see #setRules(Rule)
	 * @see smarthome.SmarthomePackage#getLuminositySensorExt_Rules()
	 * @model
	 * @generated
	 */
	Rule getRules();

	/**
	 * Sets the value of the '{@link smarthome.LuminositySensorExt#getRules <em>Rules</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Rules</em>' reference.
	 * @see #getRules()
	 * @generated
	 */
	void setRules(Rule value);

	/**
	 * Returns the value of the '<em><b>Operation</b></em>' attribute.
	 * The literals are from the enumeration {@link smarthome.OPcomp}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Operation</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operation</em>' attribute.
	 * @see smarthome.OPcomp
	 * @see #setOperation(OPcomp)
	 * @see smarthome.SmarthomePackage#getLuminositySensorExt_Operation()
	 * @model unique="false" ordered="false"
	 * @generated
	 */
	OPcomp getOperation();

	/**
	 * Sets the value of the '{@link smarthome.LuminositySensorExt#getOperation <em>Operation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Operation</em>' attribute.
	 * @see smarthome.OPcomp
	 * @see #getOperation()
	 * @generated
	 */
	void setOperation(OPcomp value);

} // LuminositySensorExt
