/**
 */
package smarthome;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Shutter</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smarthome.Shutter#getState_acti_shutter <em>State acti shutter</em>}</li>
 * </ul>
 *
 * @see smarthome.SmarthomePackage#getShutter()
 * @model
 * @generated
 */
public interface Shutter extends Actuator {
	/**
	 * Returns the value of the '<em><b>State acti shutter</b></em>' attribute.
	 * The literals are from the enumeration {@link smarthome.STATE}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>State acti shutter</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State acti shutter</em>' attribute.
	 * @see smarthome.STATE
	 * @see #setState_acti_shutter(STATE)
	 * @see smarthome.SmarthomePackage#getShutter_State_acti_shutter()
	 * @model
	 * @generated
	 */
	STATE getState_acti_shutter();

	/**
	 * Sets the value of the '{@link smarthome.Shutter#getState_acti_shutter <em>State acti shutter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>State acti shutter</em>' attribute.
	 * @see smarthome.STATE
	 * @see #getState_acti_shutter()
	 * @generated
	 */
	void setState_acti_shutter(STATE value);

} // Shutter
