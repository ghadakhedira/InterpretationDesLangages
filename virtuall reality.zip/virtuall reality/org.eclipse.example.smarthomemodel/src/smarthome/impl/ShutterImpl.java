/**
 */
package smarthome.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import smarthome.STATE;
import smarthome.Shutter;
import smarthome.SmarthomePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Shutter</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smarthome.impl.ShutterImpl#getState_acti_shutter <em>State acti shutter</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ShutterImpl extends ActuatorImpl implements Shutter {
	/**
	 * The default value of the '{@link #getState_acti_shutter() <em>State acti shutter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getState_acti_shutter()
	 * @generated
	 * @ordered
	 */
	protected static final STATE STATE_ACTI_SHUTTER_EDEFAULT = STATE.OPEN;
	/**
	 * The cached value of the '{@link #getState_acti_shutter() <em>State acti shutter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getState_acti_shutter()
	 * @generated
	 * @ordered
	 */
	protected STATE state_acti_shutter = STATE_ACTI_SHUTTER_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ShutterImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmarthomePackage.Literals.SHUTTER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public STATE getState_acti_shutter() {
		return state_acti_shutter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setState_acti_shutter(STATE newState_acti_shutter) {
		STATE oldState_acti_shutter = state_acti_shutter;
		state_acti_shutter = newState_acti_shutter == null ? STATE_ACTI_SHUTTER_EDEFAULT : newState_acti_shutter;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmarthomePackage.SHUTTER__STATE_ACTI_SHUTTER, oldState_acti_shutter, state_acti_shutter));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmarthomePackage.SHUTTER__STATE_ACTI_SHUTTER:
				return getState_acti_shutter();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmarthomePackage.SHUTTER__STATE_ACTI_SHUTTER:
				setState_acti_shutter((STATE)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmarthomePackage.SHUTTER__STATE_ACTI_SHUTTER:
				setState_acti_shutter(STATE_ACTI_SHUTTER_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmarthomePackage.SHUTTER__STATE_ACTI_SHUTTER:
				return state_acti_shutter != STATE_ACTI_SHUTTER_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (state_acti_shutter: ");
		result.append(state_acti_shutter);
		result.append(')');
		return result.toString();
	}

} //ShutterImpl
