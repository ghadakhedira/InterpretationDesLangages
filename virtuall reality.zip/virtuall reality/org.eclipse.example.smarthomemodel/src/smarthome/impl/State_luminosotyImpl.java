/**
 */
package smarthome.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import smarthome.Luminosity;
import smarthome.SmarthomePackage;
import smarthome.State_luminosoty;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>State luminosoty</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smarthome.impl.State_luminosotyImpl#getLuminosity <em>Luminosity</em>}</li>
 * </ul>
 *
 * @generated
 */
public class State_luminosotyImpl extends MinimalEObjectImpl.Container implements State_luminosoty {
	/**
	 * The default value of the '{@link #getLuminosity() <em>Luminosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLuminosity()
	 * @generated
	 * @ordered
	 */
	protected static final Luminosity LUMINOSITY_EDEFAULT = Luminosity.HIGH;
	/**
	 * The cached value of the '{@link #getLuminosity() <em>Luminosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLuminosity()
	 * @generated
	 * @ordered
	 */
	protected Luminosity luminosity = LUMINOSITY_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected State_luminosotyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmarthomePackage.Literals.STATE_LUMINOSOTY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Luminosity getLuminosity() {
		return luminosity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLuminosity(Luminosity newLuminosity) {
		Luminosity oldLuminosity = luminosity;
		luminosity = newLuminosity == null ? LUMINOSITY_EDEFAULT : newLuminosity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmarthomePackage.STATE_LUMINOSOTY__LUMINOSITY, oldLuminosity, luminosity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmarthomePackage.STATE_LUMINOSOTY__LUMINOSITY:
				return getLuminosity();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmarthomePackage.STATE_LUMINOSOTY__LUMINOSITY:
				setLuminosity((Luminosity)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmarthomePackage.STATE_LUMINOSOTY__LUMINOSITY:
				setLuminosity(LUMINOSITY_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmarthomePackage.STATE_LUMINOSOTY__LUMINOSITY:
				return luminosity != LUMINOSITY_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (luminosity: ");
		result.append(luminosity);
		result.append(')');
		return result.toString();
	}

} //State_luminosotyImpl
