/**
 */
package smarthome.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import smarthome.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class SmarthomeFactoryImpl extends EFactoryImpl implements SmarthomeFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static SmarthomeFactory init() {
		try {
			SmarthomeFactory theSmarthomeFactory = (SmarthomeFactory)EPackage.Registry.INSTANCE.getEFactory(SmarthomePackage.eNS_URI);
			if (theSmarthomeFactory != null) {
				return theSmarthomeFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new SmarthomeFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmarthomeFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case SmarthomePackage.ROOM: return createRoom();
			case SmarthomePackage.ACTUATOR: return createActuator();
			case SmarthomePackage.LUMINOSITY_SENSOR: return createLuminositySensor();
			case SmarthomePackage.RULE: return createRule();
			case SmarthomePackage.SHUTTER: return createShutter();
			case SmarthomePackage.LAMP: return createLamp();
			case SmarthomePackage.CONDITION: return createCondition();
			case SmarthomePackage.STATE_LUMINOSOTY: return createState_luminosoty();
			case SmarthomePackage.SMART_HOME: return createSmartHome();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case SmarthomePackage.OPCOMP:
				return createOPcompFromString(eDataType, initialValue);
			case SmarthomePackage.STATE:
				return createSTATEFromString(eDataType, initialValue);
			case SmarthomePackage.LUMINOSITY:
				return createLuminosityFromString(eDataType, initialValue);
			case SmarthomePackage.LUMINOSITY_SENSOR_TYPE:
				return createLuminosity_Sensor_TypeFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case SmarthomePackage.OPCOMP:
				return convertOPcompToString(eDataType, instanceValue);
			case SmarthomePackage.STATE:
				return convertSTATEToString(eDataType, instanceValue);
			case SmarthomePackage.LUMINOSITY:
				return convertLuminosityToString(eDataType, instanceValue);
			case SmarthomePackage.LUMINOSITY_SENSOR_TYPE:
				return convertLuminosity_Sensor_TypeToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Room createRoom() {
		RoomImpl room = new RoomImpl();
		return room;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Actuator createActuator() {
		ActuatorImpl actuator = new ActuatorImpl();
		return actuator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LuminositySensor createLuminositySensor() {
		LuminositySensorImpl luminositySensor = new LuminositySensorImpl();
		return luminositySensor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Rule createRule() {
		RuleImpl rule = new RuleImpl();
		return rule;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Shutter createShutter() {
		ShutterImpl shutter = new ShutterImpl();
		return shutter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Lamp createLamp() {
		LampImpl lamp = new LampImpl();
		return lamp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Condition createCondition() {
		ConditionImpl condition = new ConditionImpl();
		return condition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public State_luminosoty createState_luminosoty() {
		State_luminosotyImpl state_luminosoty = new State_luminosotyImpl();
		return state_luminosoty;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmartHome createSmartHome() {
		SmartHomeImpl smartHome = new SmartHomeImpl();
		return smartHome;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OPcomp createOPcompFromString(EDataType eDataType, String initialValue) {
		OPcomp result = OPcomp.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertOPcompToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public STATE createSTATEFromString(EDataType eDataType, String initialValue) {
		STATE result = STATE.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertSTATEToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Luminosity createLuminosityFromString(EDataType eDataType, String initialValue) {
		Luminosity result = Luminosity.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertLuminosityToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Luminosity_Sensor_Type createLuminosity_Sensor_TypeFromString(EDataType eDataType, String initialValue) {
		Luminosity_Sensor_Type result = Luminosity_Sensor_Type.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertLuminosity_Sensor_TypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SmarthomePackage getSmarthomePackage() {
		return (SmarthomePackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static SmarthomePackage getPackage() {
		return SmarthomePackage.eINSTANCE;
	}

} //SmarthomeFactoryImpl
