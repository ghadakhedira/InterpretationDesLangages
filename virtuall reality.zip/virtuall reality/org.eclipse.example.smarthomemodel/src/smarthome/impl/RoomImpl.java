/**
 */
package smarthome.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import smarthome.Actuator;
import smarthome.Room;
import smarthome.Rule;
import smarthome.SmarthomePackage;
import smarthome.State_luminosoty;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Room</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smarthome.impl.RoomImpl#getActuator <em>Actuator</em>}</li>
 *   <li>{@link smarthome.impl.RoomImpl#getRules <em>Rules</em>}</li>
 *   <li>{@link smarthome.impl.RoomImpl#getRoom_name <em>Room name</em>}</li>
 *   <li>{@link smarthome.impl.RoomImpl#getState_luminosoty <em>State luminosoty</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RoomImpl extends MinimalEObjectImpl.Container implements Room {
	/**
	 * The cached value of the '{@link #getActuator() <em>Actuator</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActuator()
	 * @generated
	 * @ordered
	 */
	protected EList<Actuator> actuator;

	/**
	 * The cached value of the '{@link #getRules() <em>Rules</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRules()
	 * @generated
	 * @ordered
	 */
	protected EList<Rule> rules;

	/**
	 * The default value of the '{@link #getRoom_name() <em>Room name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoom_name()
	 * @generated
	 * @ordered
	 */
	protected static final String ROOM_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getRoom_name() <em>Room name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoom_name()
	 * @generated
	 * @ordered
	 */
	protected String room_name = ROOM_NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getState_luminosoty() <em>State luminosoty</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getState_luminosoty()
	 * @generated
	 * @ordered
	 */
	protected EList<State_luminosoty> state_luminosoty;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RoomImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmarthomePackage.Literals.ROOM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Actuator> getActuator() {
		if (actuator == null) {
			actuator = new EObjectContainmentEList<Actuator>(Actuator.class, this, SmarthomePackage.ROOM__ACTUATOR);
		}
		return actuator;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Rule> getRules() {
		if (rules == null) {
			rules = new EObjectContainmentEList<Rule>(Rule.class, this, SmarthomePackage.ROOM__RULES);
		}
		return rules;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getRoom_name() {
		return room_name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRoom_name(String newRoom_name) {
		String oldRoom_name = room_name;
		room_name = newRoom_name;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmarthomePackage.ROOM__ROOM_NAME, oldRoom_name, room_name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<State_luminosoty> getState_luminosoty() {
		if (state_luminosoty == null) {
			state_luminosoty = new EObjectContainmentEList<State_luminosoty>(State_luminosoty.class, this, SmarthomePackage.ROOM__STATE_LUMINOSOTY);
		}
		return state_luminosoty;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case SmarthomePackage.ROOM__ACTUATOR:
				return ((InternalEList<?>)getActuator()).basicRemove(otherEnd, msgs);
			case SmarthomePackage.ROOM__RULES:
				return ((InternalEList<?>)getRules()).basicRemove(otherEnd, msgs);
			case SmarthomePackage.ROOM__STATE_LUMINOSOTY:
				return ((InternalEList<?>)getState_luminosoty()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmarthomePackage.ROOM__ACTUATOR:
				return getActuator();
			case SmarthomePackage.ROOM__RULES:
				return getRules();
			case SmarthomePackage.ROOM__ROOM_NAME:
				return getRoom_name();
			case SmarthomePackage.ROOM__STATE_LUMINOSOTY:
				return getState_luminosoty();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmarthomePackage.ROOM__ACTUATOR:
				getActuator().clear();
				getActuator().addAll((Collection<? extends Actuator>)newValue);
				return;
			case SmarthomePackage.ROOM__RULES:
				getRules().clear();
				getRules().addAll((Collection<? extends Rule>)newValue);
				return;
			case SmarthomePackage.ROOM__ROOM_NAME:
				setRoom_name((String)newValue);
				return;
			case SmarthomePackage.ROOM__STATE_LUMINOSOTY:
				getState_luminosoty().clear();
				getState_luminosoty().addAll((Collection<? extends State_luminosoty>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmarthomePackage.ROOM__ACTUATOR:
				getActuator().clear();
				return;
			case SmarthomePackage.ROOM__RULES:
				getRules().clear();
				return;
			case SmarthomePackage.ROOM__ROOM_NAME:
				setRoom_name(ROOM_NAME_EDEFAULT);
				return;
			case SmarthomePackage.ROOM__STATE_LUMINOSOTY:
				getState_luminosoty().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmarthomePackage.ROOM__ACTUATOR:
				return actuator != null && !actuator.isEmpty();
			case SmarthomePackage.ROOM__RULES:
				return rules != null && !rules.isEmpty();
			case SmarthomePackage.ROOM__ROOM_NAME:
				return ROOM_NAME_EDEFAULT == null ? room_name != null : !ROOM_NAME_EDEFAULT.equals(room_name);
			case SmarthomePackage.ROOM__STATE_LUMINOSOTY:
				return state_luminosoty != null && !state_luminosoty.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (room_name: ");
		result.append(room_name);
		result.append(')');
		return result.toString();
	}

} //RoomImpl
