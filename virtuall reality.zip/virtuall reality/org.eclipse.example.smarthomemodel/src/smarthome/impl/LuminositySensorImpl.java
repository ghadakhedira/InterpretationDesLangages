/**
 */
package smarthome.impl;

import java.lang.reflect.InvocationTargetException;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import smarthome.Luminosity;
import smarthome.LuminositySensor;
import smarthome.Luminosity_Sensor_Type;
import smarthome.OPcomp;
import smarthome.STATE;
import smarthome.SmarthomePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Luminosity Sensor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smarthome.impl.LuminositySensorImpl#getOperation <em>Operation</em>}</li>
 *   <li>{@link smarthome.impl.LuminositySensorImpl#getType_sens <em>Type sens</em>}</li>
 *   <li>{@link smarthome.impl.LuminositySensorImpl#getValue <em>Value</em>}</li>
 *   <li>{@link smarthome.impl.LuminositySensorImpl#getState <em>State</em>}</li>
 * </ul>
 *
 * @generated
 */
public class LuminositySensorImpl extends MinimalEObjectImpl.Container implements LuminositySensor {
	/**
	 * The default value of the '{@link #getOperation() <em>Operation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperation()
	 * @generated
	 * @ordered
	 */
	protected static final OPcomp OPERATION_EDEFAULT = OPcomp.INF;

	/**
	 * The cached value of the '{@link #getOperation() <em>Operation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperation()
	 * @generated
	 * @ordered
	 */
	protected OPcomp operation = OPERATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getType_sens() <em>Type sens</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType_sens()
	 * @generated
	 * @ordered
	 */
	protected static final Luminosity_Sensor_Type TYPE_SENS_EDEFAULT = Luminosity_Sensor_Type.IN;

	/**
	 * The cached value of the '{@link #getType_sens() <em>Type sens</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType_sens()
	 * @generated
	 * @ordered
	 */
	protected Luminosity_Sensor_Type type_sens = TYPE_SENS_EDEFAULT;

	/**
	 * The default value of the '{@link #getValue() <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected static final Luminosity VALUE_EDEFAULT = Luminosity.HIGH;

	/**
	 * The cached value of the '{@link #getValue() <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getValue()
	 * @generated
	 * @ordered
	 */
	protected Luminosity value = VALUE_EDEFAULT;

	/**
	 * The default value of the '{@link #getState() <em>State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getState()
	 * @generated
	 * @ordered
	 */
	protected static final STATE STATE_EDEFAULT = STATE.OPEN;

	/**
	 * The cached value of the '{@link #getState() <em>State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getState()
	 * @generated
	 * @ordered
	 */
	protected STATE state = STATE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LuminositySensorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmarthomePackage.Literals.LUMINOSITY_SENSOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OPcomp getOperation() {
		return operation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOperation(OPcomp newOperation) {
		OPcomp oldOperation = operation;
		operation = newOperation == null ? OPERATION_EDEFAULT : newOperation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmarthomePackage.LUMINOSITY_SENSOR__OPERATION, oldOperation, operation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Luminosity_Sensor_Type getType_sens() {
		return type_sens;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType_sens(Luminosity_Sensor_Type newType_sens) {
		Luminosity_Sensor_Type oldType_sens = type_sens;
		type_sens = newType_sens == null ? TYPE_SENS_EDEFAULT : newType_sens;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmarthomePackage.LUMINOSITY_SENSOR__TYPE_SENS, oldType_sens, type_sens));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Luminosity getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setValue(Luminosity newValue) {
		Luminosity oldValue = value;
		value = newValue == null ? VALUE_EDEFAULT : newValue;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmarthomePackage.LUMINOSITY_SENSOR__VALUE, oldValue, value));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public STATE getState() {
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setState(STATE newState) {
		STATE oldState = state;
		state = newState == null ? STATE_EDEFAULT : newState;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmarthomePackage.LUMINOSITY_SENSOR__STATE, oldState, state));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Luminosity Luminosity_value_OUT() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Luminosity Luminosity_value_IN() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Luminosity WhichState() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmarthomePackage.LUMINOSITY_SENSOR__OPERATION:
				return getOperation();
			case SmarthomePackage.LUMINOSITY_SENSOR__TYPE_SENS:
				return getType_sens();
			case SmarthomePackage.LUMINOSITY_SENSOR__VALUE:
				return getValue();
			case SmarthomePackage.LUMINOSITY_SENSOR__STATE:
				return getState();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmarthomePackage.LUMINOSITY_SENSOR__OPERATION:
				setOperation((OPcomp)newValue);
				return;
			case SmarthomePackage.LUMINOSITY_SENSOR__TYPE_SENS:
				setType_sens((Luminosity_Sensor_Type)newValue);
				return;
			case SmarthomePackage.LUMINOSITY_SENSOR__VALUE:
				setValue((Luminosity)newValue);
				return;
			case SmarthomePackage.LUMINOSITY_SENSOR__STATE:
				setState((STATE)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmarthomePackage.LUMINOSITY_SENSOR__OPERATION:
				setOperation(OPERATION_EDEFAULT);
				return;
			case SmarthomePackage.LUMINOSITY_SENSOR__TYPE_SENS:
				setType_sens(TYPE_SENS_EDEFAULT);
				return;
			case SmarthomePackage.LUMINOSITY_SENSOR__VALUE:
				setValue(VALUE_EDEFAULT);
				return;
			case SmarthomePackage.LUMINOSITY_SENSOR__STATE:
				setState(STATE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmarthomePackage.LUMINOSITY_SENSOR__OPERATION:
				return operation != OPERATION_EDEFAULT;
			case SmarthomePackage.LUMINOSITY_SENSOR__TYPE_SENS:
				return type_sens != TYPE_SENS_EDEFAULT;
			case SmarthomePackage.LUMINOSITY_SENSOR__VALUE:
				return value != VALUE_EDEFAULT;
			case SmarthomePackage.LUMINOSITY_SENSOR__STATE:
				return state != STATE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
			case SmarthomePackage.LUMINOSITY_SENSOR___LUMINOSITY_VALUE_OUT:
				return Luminosity_value_OUT();
			case SmarthomePackage.LUMINOSITY_SENSOR___LUMINOSITY_VALUE_IN:
				return Luminosity_value_IN();
			case SmarthomePackage.LUMINOSITY_SENSOR___WHICH_STATE:
				return WhichState();
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (operation: ");
		result.append(operation);
		result.append(", type_sens: ");
		result.append(type_sens);
		result.append(", value: ");
		result.append(value);
		result.append(", state: ");
		result.append(state);
		result.append(')');
		return result.toString();
	}

} //LuminositySensorImpl
