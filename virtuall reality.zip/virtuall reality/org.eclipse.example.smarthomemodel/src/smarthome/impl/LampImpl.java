/**
 */
package smarthome.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.ENotificationImpl;

import smarthome.Lamp;
import smarthome.STATE;
import smarthome.SmarthomePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Lamp</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link smarthome.impl.LampImpl#getState_acti_lampe <em>State acti lampe</em>}</li>
 * </ul>
 *
 * @generated
 */
public class LampImpl extends ActuatorImpl implements Lamp {
	/**
	 * The default value of the '{@link #getState_acti_lampe() <em>State acti lampe</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getState_acti_lampe()
	 * @generated
	 * @ordered
	 */
	protected static final STATE STATE_ACTI_LAMPE_EDEFAULT = STATE.OPEN;
	/**
	 * The cached value of the '{@link #getState_acti_lampe() <em>State acti lampe</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getState_acti_lampe()
	 * @generated
	 * @ordered
	 */
	protected STATE state_acti_lampe = STATE_ACTI_LAMPE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LampImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return SmarthomePackage.Literals.LAMP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public STATE getState_acti_lampe() {
		return state_acti_lampe;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setState_acti_lampe(STATE newState_acti_lampe) {
		STATE oldState_acti_lampe = state_acti_lampe;
		state_acti_lampe = newState_acti_lampe == null ? STATE_ACTI_LAMPE_EDEFAULT : newState_acti_lampe;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, SmarthomePackage.LAMP__STATE_ACTI_LAMPE, oldState_acti_lampe, state_acti_lampe));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case SmarthomePackage.LAMP__STATE_ACTI_LAMPE:
				return getState_acti_lampe();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case SmarthomePackage.LAMP__STATE_ACTI_LAMPE:
				setState_acti_lampe((STATE)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case SmarthomePackage.LAMP__STATE_ACTI_LAMPE:
				setState_acti_lampe(STATE_ACTI_LAMPE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case SmarthomePackage.LAMP__STATE_ACTI_LAMPE:
				return state_acti_lampe != STATE_ACTI_LAMPE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (state_acti_lampe: ");
		result.append(state_acti_lampe);
		result.append(')');
		return result.toString();
	}

} //LampImpl
