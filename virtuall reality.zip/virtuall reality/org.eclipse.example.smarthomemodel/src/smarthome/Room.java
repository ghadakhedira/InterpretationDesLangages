/**
 */
package smarthome;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Room</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smarthome.Room#getActuator <em>Actuator</em>}</li>
 *   <li>{@link smarthome.Room#getRules <em>Rules</em>}</li>
 *   <li>{@link smarthome.Room#getRoom_name <em>Room name</em>}</li>
 *   <li>{@link smarthome.Room#getState_luminosoty <em>State luminosoty</em>}</li>
 * </ul>
 *
 * @see smarthome.SmarthomePackage#getRoom()
 * @model
 * @generated
 */
public interface Room extends EObject {
	/**
	 * Returns the value of the '<em><b>Actuator</b></em>' containment reference list.
	 * The list contents are of type {@link smarthome.Actuator}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Actuator</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Actuator</em>' containment reference list.
	 * @see smarthome.SmarthomePackage#getRoom_Actuator()
	 * @model containment="true"
	 * @generated
	 */
	EList<Actuator> getActuator();

	/**
	 * Returns the value of the '<em><b>Rules</b></em>' containment reference list.
	 * The list contents are of type {@link smarthome.Rule}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Rules</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rules</em>' containment reference list.
	 * @see smarthome.SmarthomePackage#getRoom_Rules()
	 * @model containment="true"
	 * @generated
	 */
	EList<Rule> getRules();

	/**
	 * Returns the value of the '<em><b>Room name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Room name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Room name</em>' attribute.
	 * @see #setRoom_name(String)
	 * @see smarthome.SmarthomePackage#getRoom_Room_name()
	 * @model
	 * @generated
	 */
	String getRoom_name();

	/**
	 * Sets the value of the '{@link smarthome.Room#getRoom_name <em>Room name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Room name</em>' attribute.
	 * @see #getRoom_name()
	 * @generated
	 */
	void setRoom_name(String value);

	/**
	 * Returns the value of the '<em><b>State luminosoty</b></em>' containment reference list.
	 * The list contents are of type {@link smarthome.State_luminosoty}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>State luminosoty</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State luminosoty</em>' containment reference list.
	 * @see smarthome.SmarthomePackage#getRoom_State_luminosoty()
	 * @model containment="true"
	 * @generated
	 */
	EList<State_luminosoty> getState_luminosoty();


} // Room
