/**
 */
package smarthome;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Luminosity Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smarthome.LuminositySensor#getOperation <em>Operation</em>}</li>
 *   <li>{@link smarthome.LuminositySensor#getType_sens <em>Type sens</em>}</li>
 *   <li>{@link smarthome.LuminositySensor#getValue <em>Value</em>}</li>
 *   <li>{@link smarthome.LuminositySensor#getState <em>State</em>}</li>
 * </ul>
 *
 * @see smarthome.SmarthomePackage#getLuminositySensor()
 * @model
 * @generated
 */
public interface LuminositySensor extends EObject {
	/**
	 * Returns the value of the '<em><b>Operation</b></em>' attribute.
	 * The literals are from the enumeration {@link smarthome.OPcomp}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Operation</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operation</em>' attribute.
	 * @see smarthome.OPcomp
	 * @see #setOperation(OPcomp)
	 * @see smarthome.SmarthomePackage#getLuminositySensor_Operation()
	 * @model unique="false" ordered="false"
	 * @generated
	 */
	OPcomp getOperation();

	/**
	 * Sets the value of the '{@link smarthome.LuminositySensor#getOperation <em>Operation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Operation</em>' attribute.
	 * @see smarthome.OPcomp
	 * @see #getOperation()
	 * @generated
	 */
	void setOperation(OPcomp value);

	/**
	 * Returns the value of the '<em><b>Type sens</b></em>' attribute.
	 * The literals are from the enumeration {@link smarthome.Luminosity_Sensor_Type}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type sens</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type sens</em>' attribute.
	 * @see smarthome.Luminosity_Sensor_Type
	 * @see #setType_sens(Luminosity_Sensor_Type)
	 * @see smarthome.SmarthomePackage#getLuminositySensor_Type_sens()
	 * @model
	 * @generated
	 */
	Luminosity_Sensor_Type getType_sens();

	/**
	 * Sets the value of the '{@link smarthome.LuminositySensor#getType_sens <em>Type sens</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type sens</em>' attribute.
	 * @see smarthome.Luminosity_Sensor_Type
	 * @see #getType_sens()
	 * @generated
	 */
	void setType_sens(Luminosity_Sensor_Type value);

	/**
	 * Returns the value of the '<em><b>Value</b></em>' attribute.
	 * The literals are from the enumeration {@link smarthome.Luminosity}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Value</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' attribute.
	 * @see smarthome.Luminosity
	 * @see #setValue(Luminosity)
	 * @see smarthome.SmarthomePackage#getLuminositySensor_Value()
	 * @model
	 * @generated
	 */
	Luminosity getValue();

	/**
	 * Sets the value of the '{@link smarthome.LuminositySensor#getValue <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value</em>' attribute.
	 * @see smarthome.Luminosity
	 * @see #getValue()
	 * @generated
	 */
	void setValue(Luminosity value);

	/**
	 * Returns the value of the '<em><b>State</b></em>' attribute.
	 * The literals are from the enumeration {@link smarthome.STATE}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>State</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State</em>' attribute.
	 * @see smarthome.STATE
	 * @see #setState(STATE)
	 * @see smarthome.SmarthomePackage#getLuminositySensor_State()
	 * @model
	 * @generated
	 */
	STATE getState();

	/**
	 * Sets the value of the '{@link smarthome.LuminositySensor#getState <em>State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>State</em>' attribute.
	 * @see smarthome.STATE
	 * @see #getState()
	 * @generated
	 */
	void setState(STATE value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	Luminosity Luminosity_value_OUT();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	Luminosity Luminosity_value_IN();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	Luminosity WhichState();

} // LuminositySensor
