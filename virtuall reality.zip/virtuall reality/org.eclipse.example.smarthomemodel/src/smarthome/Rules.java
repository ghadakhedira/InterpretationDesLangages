/**
 */
package smarthome;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Rules</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see smarthome.SmarthomePackage#getRules()
 * @model
 * @generated
 */
public interface Rules extends EObject {
} // Rules
