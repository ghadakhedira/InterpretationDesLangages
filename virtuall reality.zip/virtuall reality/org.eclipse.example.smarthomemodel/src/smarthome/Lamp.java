/**
 */
package smarthome;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Lamp</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smarthome.Lamp#getState_acti_lampe <em>State acti lampe</em>}</li>
 * </ul>
 *
 * @see smarthome.SmarthomePackage#getLamp()
 * @model
 * @generated
 */
public interface Lamp extends Actuator {
	/**
	 * Returns the value of the '<em><b>State acti lampe</b></em>' attribute.
	 * The literals are from the enumeration {@link smarthome.STATE}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>State acti lampe</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State acti lampe</em>' attribute.
	 * @see smarthome.STATE
	 * @see #setState_acti_lampe(STATE)
	 * @see smarthome.SmarthomePackage#getLamp_State_acti_lampe()
	 * @model
	 * @generated
	 */
	STATE getState_acti_lampe();

	/**
	 * Sets the value of the '{@link smarthome.Lamp#getState_acti_lampe <em>State acti lampe</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>State acti lampe</em>' attribute.
	 * @see smarthome.STATE
	 * @see #getState_acti_lampe()
	 * @generated
	 */
	void setState_acti_lampe(STATE value);

} // Lamp
