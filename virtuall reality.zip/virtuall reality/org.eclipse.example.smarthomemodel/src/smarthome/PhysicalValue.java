/**
 */
package smarthome;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Physical Value</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see smarthome.SmarthomePackage#getPhysicalValue()
 * @model
 * @generated
 */
public interface PhysicalValue extends EObject {
} // PhysicalValue
