/**
 */
package smarthome;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Actuator</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smarthome.Actuator#getActuator_name <em>Actuator name</em>}</li>
 *   <li>{@link smarthome.Actuator#getState <em>State</em>}</li>
 *   <li>{@link smarthome.Actuator#getRule <em>Rule</em>}</li>
 * </ul>
 *
 * @see smarthome.SmarthomePackage#getActuator()
 * @model
 * @generated
 */
public interface Actuator extends EObject {
	/**
	 * Returns the value of the '<em><b>Actuator name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Actuator name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Actuator name</em>' attribute.
	 * @see #setActuator_name(String)
	 * @see smarthome.SmarthomePackage#getActuator_Actuator_name()
	 * @model
	 * @generated
	 */
	String getActuator_name();

	/**
	 * Sets the value of the '{@link smarthome.Actuator#getActuator_name <em>Actuator name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Actuator name</em>' attribute.
	 * @see #getActuator_name()
	 * @generated
	 */
	void setActuator_name(String value);

	/**
	 * Returns the value of the '<em><b>State</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>State</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State</em>' attribute.
	 * @see #setState(int)
	 * @see smarthome.SmarthomePackage#getActuator_State()
	 * @model unique="false"
	 * @generated
	 */
	int getState();

	/**
	 * Sets the value of the '{@link smarthome.Actuator#getState <em>State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>State</em>' attribute.
	 * @see #getState()
	 * @generated
	 */
	void setState(int value);

	/**
	 * Returns the value of the '<em><b>Rule</b></em>' containment reference list.
	 * The list contents are of type {@link smarthome.Rule}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Rule</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rule</em>' containment reference list.
	 * @see smarthome.SmarthomePackage#getActuator_Rule()
	 * @model containment="true"
	 * @generated
	 */
	EList<Rule> getRule();

} // Actuator
