/**
 */
package smarthome;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>State luminosoty</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smarthome.State_luminosoty#getLuminosity <em>Luminosity</em>}</li>
 * </ul>
 *
 * @see smarthome.SmarthomePackage#getState_luminosoty()
 * @model
 * @generated
 */
public interface State_luminosoty extends EObject {
	/**
	 * Returns the value of the '<em><b>Luminosity</b></em>' attribute.
	 * The literals are from the enumeration {@link smarthome.Luminosity}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Luminosity</em>' attribute list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Luminosity</em>' attribute.
	 * @see smarthome.Luminosity
	 * @see #setLuminosity(Luminosity)
	 * @see smarthome.SmarthomePackage#getState_luminosoty_Luminosity()
	 * @model
	 * @generated
	 */
	Luminosity getLuminosity();

	/**
	 * Sets the value of the '{@link smarthome.State_luminosoty#getLuminosity <em>Luminosity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Luminosity</em>' attribute.
	 * @see smarthome.Luminosity
	 * @see #getLuminosity()
	 * @generated
	 */
	void setLuminosity(Luminosity value);

} // State_luminosoty
