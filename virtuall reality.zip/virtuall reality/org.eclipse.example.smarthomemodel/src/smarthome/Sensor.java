/**
 */
package smarthome;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sensor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smarthome.Sensor#getSensor_name <em>Sensor name</em>}</li>
 *   <li>{@link smarthome.Sensor#isState <em>State</em>}</li>
 *   <li>{@link smarthome.Sensor#getType <em>Type</em>}</li>
 *   <li>{@link smarthome.Sensor#getOperation <em>Operation</em>}</li>
 * </ul>
 *
 * @see smarthome.SmarthomePackage#getSensor()
 * @model
 * @generated
 */
public interface Sensor extends EObject {
	/**
	 * Returns the value of the '<em><b>Sensor name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sensor name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sensor name</em>' attribute.
	 * @see #setSensor_name(String)
	 * @see smarthome.SmarthomePackage#getSensor_Sensor_name()
	 * @model
	 * @generated
	 */
	String getSensor_name();

	/**
	 * Sets the value of the '{@link smarthome.Sensor#getSensor_name <em>Sensor name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sensor name</em>' attribute.
	 * @see #getSensor_name()
	 * @generated
	 */
	void setSensor_name(String value);

	/**
	 * Returns the value of the '<em><b>State</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>State</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State</em>' attribute.
	 * @see #setState(boolean)
	 * @see smarthome.SmarthomePackage#getSensor_State()
	 * @model unique="false"
	 * @generated
	 */
	boolean isState();

	/**
	 * Sets the value of the '{@link smarthome.Sensor#isState <em>State</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>State</em>' attribute.
	 * @see #isState()
	 * @generated
	 */
	void setState(boolean value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see #setType(String)
	 * @see smarthome.SmarthomePackage#getSensor_Type()
	 * @model unique="false"
	 * @generated
	 */
	String getType();

	/**
	 * Sets the value of the '{@link smarthome.Sensor#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see #getType()
	 * @generated
	 */
	void setType(String value);

	/**
	 * Returns the value of the '<em><b>Operation</b></em>' attribute.
	 * The literals are from the enumeration {@link smarthome.OPcomp}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Operation</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operation</em>' attribute.
	 * @see smarthome.OPcomp
	 * @see #setOperation(OPcomp)
	 * @see smarthome.SmarthomePackage#getSensor_Operation()
	 * @model unique="false" ordered="false"
	 * @generated
	 */
	OPcomp getOperation();

	/**
	 * Sets the value of the '{@link smarthome.Sensor#getOperation <em>Operation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Operation</em>' attribute.
	 * @see smarthome.OPcomp
	 * @see #getOperation()
	 * @generated
	 */
	void setOperation(OPcomp value);

} // Sensor
