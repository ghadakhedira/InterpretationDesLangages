/**
 */
package smarthome;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see smarthome.SmarthomeFactory
 * @model kind="package"
 * @generated
 */
public interface SmarthomePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "smarthome";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.eclipse.org/example/smarthomemodel";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "org.eclipse.example.smarthomemodel";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	SmarthomePackage eINSTANCE = smarthome.impl.SmarthomePackageImpl.init();

	/**
	 * The meta object id for the '{@link smarthome.impl.RoomImpl <em>Room</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smarthome.impl.RoomImpl
	 * @see smarthome.impl.SmarthomePackageImpl#getRoom()
	 * @generated
	 */
	int ROOM = 0;

	/**
	 * The feature id for the '<em><b>Actuator</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__ACTUATOR = 0;

	/**
	 * The feature id for the '<em><b>Rules</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__RULES = 1;

	/**
	 * The feature id for the '<em><b>Room name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__ROOM_NAME = 2;

	/**
	 * The feature id for the '<em><b>State luminosoty</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM__STATE_LUMINOSOTY = 3;

	/**
	 * The number of structural features of the '<em>Room</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Room</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROOM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link smarthome.impl.ActuatorImpl <em>Actuator</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smarthome.impl.ActuatorImpl
	 * @see smarthome.impl.SmarthomePackageImpl#getActuator()
	 * @generated
	 */
	int ACTUATOR = 1;

	/**
	 * The feature id for the '<em><b>Actuator name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__ACTUATOR_NAME = 0;

	/**
	 * The feature id for the '<em><b>State</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__STATE = 1;

	/**
	 * The feature id for the '<em><b>Rule</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR__RULE = 2;

	/**
	 * The number of structural features of the '<em>Actuator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Actuator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTUATOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link smarthome.impl.LuminositySensorImpl <em>Luminosity Sensor</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smarthome.impl.LuminositySensorImpl
	 * @see smarthome.impl.SmarthomePackageImpl#getLuminositySensor()
	 * @generated
	 */
	int LUMINOSITY_SENSOR = 2;

	/**
	 * The feature id for the '<em><b>Operation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LUMINOSITY_SENSOR__OPERATION = 0;

	/**
	 * The feature id for the '<em><b>Type sens</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LUMINOSITY_SENSOR__TYPE_SENS = 1;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LUMINOSITY_SENSOR__VALUE = 2;

	/**
	 * The feature id for the '<em><b>State</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LUMINOSITY_SENSOR__STATE = 3;

	/**
	 * The number of structural features of the '<em>Luminosity Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LUMINOSITY_SENSOR_FEATURE_COUNT = 4;

	/**
	 * The operation id for the '<em>Luminosity value OUT</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LUMINOSITY_SENSOR___LUMINOSITY_VALUE_OUT = 0;

	/**
	 * The operation id for the '<em>Luminosity value IN</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LUMINOSITY_SENSOR___LUMINOSITY_VALUE_IN = 1;

	/**
	 * The operation id for the '<em>Which State</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LUMINOSITY_SENSOR___WHICH_STATE = 2;

	/**
	 * The number of operations of the '<em>Luminosity Sensor</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LUMINOSITY_SENSOR_OPERATION_COUNT = 3;

	/**
	 * The meta object id for the '{@link smarthome.impl.RuleImpl <em>Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smarthome.impl.RuleImpl
	 * @see smarthome.impl.SmarthomePackageImpl#getRule()
	 * @generated
	 */
	int RULE = 3;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE__DESCRIPTION = 0;

	/**
	 * The feature id for the '<em><b>Condition</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE__CONDITION = 1;

	/**
	 * The feature id for the '<em><b>Luminositysensor</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE__LUMINOSITYSENSOR = 2;

	/**
	 * The number of structural features of the '<em>Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE_FEATURE_COUNT = 3;

	/**
	 * The operation id for the '<em>Result</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE___RESULT = 0;

	/**
	 * The number of operations of the '<em>Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link smarthome.impl.ShutterImpl <em>Shutter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smarthome.impl.ShutterImpl
	 * @see smarthome.impl.SmarthomePackageImpl#getShutter()
	 * @generated
	 */
	int SHUTTER = 4;

	/**
	 * The feature id for the '<em><b>Actuator name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHUTTER__ACTUATOR_NAME = ACTUATOR__ACTUATOR_NAME;

	/**
	 * The feature id for the '<em><b>State</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHUTTER__STATE = ACTUATOR__STATE;

	/**
	 * The feature id for the '<em><b>Rule</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHUTTER__RULE = ACTUATOR__RULE;

	/**
	 * The feature id for the '<em><b>State acti shutter</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHUTTER__STATE_ACTI_SHUTTER = ACTUATOR_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Shutter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHUTTER_FEATURE_COUNT = ACTUATOR_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Shutter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SHUTTER_OPERATION_COUNT = ACTUATOR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link smarthome.impl.LampImpl <em>Lamp</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smarthome.impl.LampImpl
	 * @see smarthome.impl.SmarthomePackageImpl#getLamp()
	 * @generated
	 */
	int LAMP = 5;

	/**
	 * The feature id for the '<em><b>Actuator name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAMP__ACTUATOR_NAME = ACTUATOR__ACTUATOR_NAME;

	/**
	 * The feature id for the '<em><b>State</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAMP__STATE = ACTUATOR__STATE;

	/**
	 * The feature id for the '<em><b>Rule</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAMP__RULE = ACTUATOR__RULE;

	/**
	 * The feature id for the '<em><b>State acti lampe</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAMP__STATE_ACTI_LAMPE = ACTUATOR_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Lamp</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAMP_FEATURE_COUNT = ACTUATOR_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Lamp</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAMP_OPERATION_COUNT = ACTUATOR_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link smarthome.impl.ConditionImpl <em>Condition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smarthome.impl.ConditionImpl
	 * @see smarthome.impl.SmarthomePackageImpl#getCondition()
	 * @generated
	 */
	int CONDITION = 6;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION__VALUE = 0;

	/**
	 * The feature id for the '<em><b>Luminositysensor</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION__LUMINOSITYSENSOR = 1;

	/**
	 * The number of structural features of the '<em>Condition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION_FEATURE_COUNT = 2;

	/**
	 * The operation id for the '<em>Eval</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION___EVAL = 0;

	/**
	 * The number of operations of the '<em>Condition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONDITION_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link smarthome.impl.State_luminosotyImpl <em>State luminosoty</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smarthome.impl.State_luminosotyImpl
	 * @see smarthome.impl.SmarthomePackageImpl#getState_luminosoty()
	 * @generated
	 */
	int STATE_LUMINOSOTY = 7;

	/**
	 * The feature id for the '<em><b>Luminosity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_LUMINOSOTY__LUMINOSITY = 0;

	/**
	 * The number of structural features of the '<em>State luminosoty</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_LUMINOSOTY_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>State luminosoty</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_LUMINOSOTY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link smarthome.impl.SmartHomeImpl <em>Smart Home</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smarthome.impl.SmartHomeImpl
	 * @see smarthome.impl.SmarthomePackageImpl#getSmartHome()
	 * @generated
	 */
	int SMART_HOME = 8;

	/**
	 * The feature id for the '<em><b>Room</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_HOME__ROOM = 0;

	/**
	 * The number of structural features of the '<em>Smart Home</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_HOME_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Smart Home</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_HOME_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link smarthome.OPcomp <em>OPcomp</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smarthome.OPcomp
	 * @see smarthome.impl.SmarthomePackageImpl#getOPcomp()
	 * @generated
	 */
	int OPCOMP = 9;


	/**
	 * The meta object id for the '{@link smarthome.STATE <em>STATE</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smarthome.STATE
	 * @see smarthome.impl.SmarthomePackageImpl#getSTATE()
	 * @generated
	 */
	int STATE = 10;


	/**
	 * The meta object id for the '{@link smarthome.Luminosity <em>Luminosity</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smarthome.Luminosity
	 * @see smarthome.impl.SmarthomePackageImpl#getLuminosity()
	 * @generated
	 */
	int LUMINOSITY = 11;


	/**
	 * The meta object id for the '{@link smarthome.Luminosity_Sensor_Type <em>Luminosity Sensor Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see smarthome.Luminosity_Sensor_Type
	 * @see smarthome.impl.SmarthomePackageImpl#getLuminosity_Sensor_Type()
	 * @generated
	 */
	int LUMINOSITY_SENSOR_TYPE = 12;


	/**
	 * Returns the meta object for class '{@link smarthome.Room <em>Room</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Room</em>'.
	 * @see smarthome.Room
	 * @generated
	 */
	EClass getRoom();

	/**
	 * Returns the meta object for the containment reference list '{@link smarthome.Room#getActuator <em>Actuator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Actuator</em>'.
	 * @see smarthome.Room#getActuator()
	 * @see #getRoom()
	 * @generated
	 */
	EReference getRoom_Actuator();

	/**
	 * Returns the meta object for the containment reference list '{@link smarthome.Room#getRules <em>Rules</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Rules</em>'.
	 * @see smarthome.Room#getRules()
	 * @see #getRoom()
	 * @generated
	 */
	EReference getRoom_Rules();

	/**
	 * Returns the meta object for the attribute '{@link smarthome.Room#getRoom_name <em>Room name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Room name</em>'.
	 * @see smarthome.Room#getRoom_name()
	 * @see #getRoom()
	 * @generated
	 */
	EAttribute getRoom_Room_name();

	/**
	 * Returns the meta object for the containment reference list '{@link smarthome.Room#getState_luminosoty <em>State luminosoty</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>State luminosoty</em>'.
	 * @see smarthome.Room#getState_luminosoty()
	 * @see #getRoom()
	 * @generated
	 */
	EReference getRoom_State_luminosoty();

	/**
	 * Returns the meta object for class '{@link smarthome.Actuator <em>Actuator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Actuator</em>'.
	 * @see smarthome.Actuator
	 * @generated
	 */
	EClass getActuator();

	/**
	 * Returns the meta object for the attribute '{@link smarthome.Actuator#getActuator_name <em>Actuator name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Actuator name</em>'.
	 * @see smarthome.Actuator#getActuator_name()
	 * @see #getActuator()
	 * @generated
	 */
	EAttribute getActuator_Actuator_name();

	/**
	 * Returns the meta object for the attribute '{@link smarthome.Actuator#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>State</em>'.
	 * @see smarthome.Actuator#getState()
	 * @see #getActuator()
	 * @generated
	 */
	EAttribute getActuator_State();

	/**
	 * Returns the meta object for the containment reference list '{@link smarthome.Actuator#getRule <em>Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Rule</em>'.
	 * @see smarthome.Actuator#getRule()
	 * @see #getActuator()
	 * @generated
	 */
	EReference getActuator_Rule();

	/**
	 * Returns the meta object for class '{@link smarthome.LuminositySensor <em>Luminosity Sensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Luminosity Sensor</em>'.
	 * @see smarthome.LuminositySensor
	 * @generated
	 */
	EClass getLuminositySensor();

	/**
	 * Returns the meta object for the attribute '{@link smarthome.LuminositySensor#getOperation <em>Operation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Operation</em>'.
	 * @see smarthome.LuminositySensor#getOperation()
	 * @see #getLuminositySensor()
	 * @generated
	 */
	EAttribute getLuminositySensor_Operation();

	/**
	 * Returns the meta object for the attribute '{@link smarthome.LuminositySensor#getType_sens <em>Type sens</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type sens</em>'.
	 * @see smarthome.LuminositySensor#getType_sens()
	 * @see #getLuminositySensor()
	 * @generated
	 */
	EAttribute getLuminositySensor_Type_sens();

	/**
	 * Returns the meta object for the attribute '{@link smarthome.LuminositySensor#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see smarthome.LuminositySensor#getValue()
	 * @see #getLuminositySensor()
	 * @generated
	 */
	EAttribute getLuminositySensor_Value();

	/**
	 * Returns the meta object for the attribute '{@link smarthome.LuminositySensor#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>State</em>'.
	 * @see smarthome.LuminositySensor#getState()
	 * @see #getLuminositySensor()
	 * @generated
	 */
	EAttribute getLuminositySensor_State();

	/**
	 * Returns the meta object for the '{@link smarthome.LuminositySensor#Luminosity_value_OUT() <em>Luminosity value OUT</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Luminosity value OUT</em>' operation.
	 * @see smarthome.LuminositySensor#Luminosity_value_OUT()
	 * @generated
	 */
	EOperation getLuminositySensor__Luminosity_value_OUT();

	/**
	 * Returns the meta object for the '{@link smarthome.LuminositySensor#Luminosity_value_IN() <em>Luminosity value IN</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Luminosity value IN</em>' operation.
	 * @see smarthome.LuminositySensor#Luminosity_value_IN()
	 * @generated
	 */
	EOperation getLuminositySensor__Luminosity_value_IN();

	/**
	 * Returns the meta object for the '{@link smarthome.LuminositySensor#WhichState() <em>Which State</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Which State</em>' operation.
	 * @see smarthome.LuminositySensor#WhichState()
	 * @generated
	 */
	EOperation getLuminositySensor__WhichState();

	/**
	 * Returns the meta object for class '{@link smarthome.Rule <em>Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Rule</em>'.
	 * @see smarthome.Rule
	 * @generated
	 */
	EClass getRule();

	/**
	 * Returns the meta object for the attribute '{@link smarthome.Rule#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see smarthome.Rule#getDescription()
	 * @see #getRule()
	 * @generated
	 */
	EAttribute getRule_Description();

	/**
	 * Returns the meta object for the containment reference list '{@link smarthome.Rule#getCondition <em>Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Condition</em>'.
	 * @see smarthome.Rule#getCondition()
	 * @see #getRule()
	 * @generated
	 */
	EReference getRule_Condition();

	/**
	 * Returns the meta object for the containment reference list '{@link smarthome.Rule#getLuminositysensor <em>Luminositysensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Luminositysensor</em>'.
	 * @see smarthome.Rule#getLuminositysensor()
	 * @see #getRule()
	 * @generated
	 */
	EReference getRule_Luminositysensor();

	/**
	 * Returns the meta object for the '{@link smarthome.Rule#result() <em>Result</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Result</em>' operation.
	 * @see smarthome.Rule#result()
	 * @generated
	 */
	EOperation getRule__Result();

	/**
	 * Returns the meta object for class '{@link smarthome.Shutter <em>Shutter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Shutter</em>'.
	 * @see smarthome.Shutter
	 * @generated
	 */
	EClass getShutter();

	/**
	 * Returns the meta object for the attribute '{@link smarthome.Shutter#getState_acti_shutter <em>State acti shutter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>State acti shutter</em>'.
	 * @see smarthome.Shutter#getState_acti_shutter()
	 * @see #getShutter()
	 * @generated
	 */
	EAttribute getShutter_State_acti_shutter();

	/**
	 * Returns the meta object for class '{@link smarthome.Lamp <em>Lamp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Lamp</em>'.
	 * @see smarthome.Lamp
	 * @generated
	 */
	EClass getLamp();

	/**
	 * Returns the meta object for the attribute '{@link smarthome.Lamp#getState_acti_lampe <em>State acti lampe</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>State acti lampe</em>'.
	 * @see smarthome.Lamp#getState_acti_lampe()
	 * @see #getLamp()
	 * @generated
	 */
	EAttribute getLamp_State_acti_lampe();

	/**
	 * Returns the meta object for class '{@link smarthome.Condition <em>Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Condition</em>'.
	 * @see smarthome.Condition
	 * @generated
	 */
	EClass getCondition();

	/**
	 * Returns the meta object for the attribute '{@link smarthome.Condition#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see smarthome.Condition#getValue()
	 * @see #getCondition()
	 * @generated
	 */
	EAttribute getCondition_Value();

	/**
	 * Returns the meta object for the containment reference list '{@link smarthome.Condition#getLuminositysensor <em>Luminositysensor</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Luminositysensor</em>'.
	 * @see smarthome.Condition#getLuminositysensor()
	 * @see #getCondition()
	 * @generated
	 */
	EReference getCondition_Luminositysensor();

	/**
	 * Returns the meta object for the '{@link smarthome.Condition#eval() <em>Eval</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Eval</em>' operation.
	 * @see smarthome.Condition#eval()
	 * @generated
	 */
	EOperation getCondition__Eval();

	/**
	 * Returns the meta object for class '{@link smarthome.State_luminosoty <em>State luminosoty</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>State luminosoty</em>'.
	 * @see smarthome.State_luminosoty
	 * @generated
	 */
	EClass getState_luminosoty();

	/**
	 * Returns the meta object for the attribute '{@link smarthome.State_luminosoty#getLuminosity <em>Luminosity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Luminosity</em>'.
	 * @see smarthome.State_luminosoty#getLuminosity()
	 * @see #getState_luminosoty()
	 * @generated
	 */
	EAttribute getState_luminosoty_Luminosity();

	/**
	 * Returns the meta object for class '{@link smarthome.SmartHome <em>Smart Home</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Smart Home</em>'.
	 * @see smarthome.SmartHome
	 * @generated
	 */
	EClass getSmartHome();

	/**
	 * Returns the meta object for the containment reference list '{@link smarthome.SmartHome#getRoom <em>Room</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Room</em>'.
	 * @see smarthome.SmartHome#getRoom()
	 * @see #getSmartHome()
	 * @generated
	 */
	EReference getSmartHome_Room();

	/**
	 * Returns the meta object for enum '{@link smarthome.OPcomp <em>OPcomp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>OPcomp</em>'.
	 * @see smarthome.OPcomp
	 * @generated
	 */
	EEnum getOPcomp();

	/**
	 * Returns the meta object for enum '{@link smarthome.STATE <em>STATE</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>STATE</em>'.
	 * @see smarthome.STATE
	 * @generated
	 */
	EEnum getSTATE();

	/**
	 * Returns the meta object for enum '{@link smarthome.Luminosity <em>Luminosity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Luminosity</em>'.
	 * @see smarthome.Luminosity
	 * @generated
	 */
	EEnum getLuminosity();

	/**
	 * Returns the meta object for enum '{@link smarthome.Luminosity_Sensor_Type <em>Luminosity Sensor Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Luminosity Sensor Type</em>'.
	 * @see smarthome.Luminosity_Sensor_Type
	 * @generated
	 */
	EEnum getLuminosity_Sensor_Type();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	SmarthomeFactory getSmarthomeFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link smarthome.impl.RoomImpl <em>Room</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smarthome.impl.RoomImpl
		 * @see smarthome.impl.SmarthomePackageImpl#getRoom()
		 * @generated
		 */
		EClass ROOM = eINSTANCE.getRoom();

		/**
		 * The meta object literal for the '<em><b>Actuator</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROOM__ACTUATOR = eINSTANCE.getRoom_Actuator();

		/**
		 * The meta object literal for the '<em><b>Rules</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROOM__RULES = eINSTANCE.getRoom_Rules();

		/**
		 * The meta object literal for the '<em><b>Room name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROOM__ROOM_NAME = eINSTANCE.getRoom_Room_name();

		/**
		 * The meta object literal for the '<em><b>State luminosoty</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROOM__STATE_LUMINOSOTY = eINSTANCE.getRoom_State_luminosoty();

		/**
		 * The meta object literal for the '{@link smarthome.impl.ActuatorImpl <em>Actuator</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smarthome.impl.ActuatorImpl
		 * @see smarthome.impl.SmarthomePackageImpl#getActuator()
		 * @generated
		 */
		EClass ACTUATOR = eINSTANCE.getActuator();

		/**
		 * The meta object literal for the '<em><b>Actuator name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTUATOR__ACTUATOR_NAME = eINSTANCE.getActuator_Actuator_name();

		/**
		 * The meta object literal for the '<em><b>State</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTUATOR__STATE = eINSTANCE.getActuator_State();

		/**
		 * The meta object literal for the '<em><b>Rule</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTUATOR__RULE = eINSTANCE.getActuator_Rule();

		/**
		 * The meta object literal for the '{@link smarthome.impl.LuminositySensorImpl <em>Luminosity Sensor</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smarthome.impl.LuminositySensorImpl
		 * @see smarthome.impl.SmarthomePackageImpl#getLuminositySensor()
		 * @generated
		 */
		EClass LUMINOSITY_SENSOR = eINSTANCE.getLuminositySensor();

		/**
		 * The meta object literal for the '<em><b>Operation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LUMINOSITY_SENSOR__OPERATION = eINSTANCE.getLuminositySensor_Operation();

		/**
		 * The meta object literal for the '<em><b>Type sens</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LUMINOSITY_SENSOR__TYPE_SENS = eINSTANCE.getLuminositySensor_Type_sens();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LUMINOSITY_SENSOR__VALUE = eINSTANCE.getLuminositySensor_Value();

		/**
		 * The meta object literal for the '<em><b>State</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LUMINOSITY_SENSOR__STATE = eINSTANCE.getLuminositySensor_State();

		/**
		 * The meta object literal for the '<em><b>Luminosity value OUT</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation LUMINOSITY_SENSOR___LUMINOSITY_VALUE_OUT = eINSTANCE.getLuminositySensor__Luminosity_value_OUT();

		/**
		 * The meta object literal for the '<em><b>Luminosity value IN</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation LUMINOSITY_SENSOR___LUMINOSITY_VALUE_IN = eINSTANCE.getLuminositySensor__Luminosity_value_IN();

		/**
		 * The meta object literal for the '<em><b>Which State</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation LUMINOSITY_SENSOR___WHICH_STATE = eINSTANCE.getLuminositySensor__WhichState();

		/**
		 * The meta object literal for the '{@link smarthome.impl.RuleImpl <em>Rule</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smarthome.impl.RuleImpl
		 * @see smarthome.impl.SmarthomePackageImpl#getRule()
		 * @generated
		 */
		EClass RULE = eINSTANCE.getRule();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RULE__DESCRIPTION = eINSTANCE.getRule_Description();

		/**
		 * The meta object literal for the '<em><b>Condition</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RULE__CONDITION = eINSTANCE.getRule_Condition();

		/**
		 * The meta object literal for the '<em><b>Luminositysensor</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RULE__LUMINOSITYSENSOR = eINSTANCE.getRule_Luminositysensor();

		/**
		 * The meta object literal for the '<em><b>Result</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation RULE___RESULT = eINSTANCE.getRule__Result();

		/**
		 * The meta object literal for the '{@link smarthome.impl.ShutterImpl <em>Shutter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smarthome.impl.ShutterImpl
		 * @see smarthome.impl.SmarthomePackageImpl#getShutter()
		 * @generated
		 */
		EClass SHUTTER = eINSTANCE.getShutter();

		/**
		 * The meta object literal for the '<em><b>State acti shutter</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SHUTTER__STATE_ACTI_SHUTTER = eINSTANCE.getShutter_State_acti_shutter();

		/**
		 * The meta object literal for the '{@link smarthome.impl.LampImpl <em>Lamp</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smarthome.impl.LampImpl
		 * @see smarthome.impl.SmarthomePackageImpl#getLamp()
		 * @generated
		 */
		EClass LAMP = eINSTANCE.getLamp();

		/**
		 * The meta object literal for the '<em><b>State acti lampe</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LAMP__STATE_ACTI_LAMPE = eINSTANCE.getLamp_State_acti_lampe();

		/**
		 * The meta object literal for the '{@link smarthome.impl.ConditionImpl <em>Condition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smarthome.impl.ConditionImpl
		 * @see smarthome.impl.SmarthomePackageImpl#getCondition()
		 * @generated
		 */
		EClass CONDITION = eINSTANCE.getCondition();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONDITION__VALUE = eINSTANCE.getCondition_Value();

		/**
		 * The meta object literal for the '<em><b>Luminositysensor</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONDITION__LUMINOSITYSENSOR = eINSTANCE.getCondition_Luminositysensor();

		/**
		 * The meta object literal for the '<em><b>Eval</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CONDITION___EVAL = eINSTANCE.getCondition__Eval();

		/**
		 * The meta object literal for the '{@link smarthome.impl.State_luminosotyImpl <em>State luminosoty</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smarthome.impl.State_luminosotyImpl
		 * @see smarthome.impl.SmarthomePackageImpl#getState_luminosoty()
		 * @generated
		 */
		EClass STATE_LUMINOSOTY = eINSTANCE.getState_luminosoty();

		/**
		 * The meta object literal for the '<em><b>Luminosity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATE_LUMINOSOTY__LUMINOSITY = eINSTANCE.getState_luminosoty_Luminosity();

		/**
		 * The meta object literal for the '{@link smarthome.impl.SmartHomeImpl <em>Smart Home</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smarthome.impl.SmartHomeImpl
		 * @see smarthome.impl.SmarthomePackageImpl#getSmartHome()
		 * @generated
		 */
		EClass SMART_HOME = eINSTANCE.getSmartHome();

		/**
		 * The meta object literal for the '<em><b>Room</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SMART_HOME__ROOM = eINSTANCE.getSmartHome_Room();

		/**
		 * The meta object literal for the '{@link smarthome.OPcomp <em>OPcomp</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smarthome.OPcomp
		 * @see smarthome.impl.SmarthomePackageImpl#getOPcomp()
		 * @generated
		 */
		EEnum OPCOMP = eINSTANCE.getOPcomp();

		/**
		 * The meta object literal for the '{@link smarthome.STATE <em>STATE</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smarthome.STATE
		 * @see smarthome.impl.SmarthomePackageImpl#getSTATE()
		 * @generated
		 */
		EEnum STATE = eINSTANCE.getSTATE();

		/**
		 * The meta object literal for the '{@link smarthome.Luminosity <em>Luminosity</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smarthome.Luminosity
		 * @see smarthome.impl.SmarthomePackageImpl#getLuminosity()
		 * @generated
		 */
		EEnum LUMINOSITY = eINSTANCE.getLuminosity();

		/**
		 * The meta object literal for the '{@link smarthome.Luminosity_Sensor_Type <em>Luminosity Sensor Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see smarthome.Luminosity_Sensor_Type
		 * @see smarthome.impl.SmarthomePackageImpl#getLuminosity_Sensor_Type()
		 * @generated
		 */
		EEnum LUMINOSITY_SENSOR_TYPE = eINSTANCE.getLuminosity_Sensor_Type();

	}

} //SmarthomePackage
