/**
 */
package smarthome;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Environment</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link smarthome.Environment#getLuminosity <em>Luminosity</em>}</li>
 * </ul>
 *
 * @see smarthome.SmarthomePackage#getEnvironment()
 * @model
 * @generated
 */
public interface Environment extends EObject {
	/**
	 * Returns the value of the '<em><b>Luminosity</b></em>' containment reference list.
	 * The list contents are of type {@link smarthome.Luminosity}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Luminosity</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Luminosity</em>' containment reference list.
	 * @see smarthome.SmarthomePackage#getEnvironment_Luminosity()
	 * @model containment="true"
	 * @generated
	 */
	EList<Luminosity> getLuminosity();

} // Environment
