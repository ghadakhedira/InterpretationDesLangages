package org.eclipse.example.smarthomemodel.k3;

import java.util.Map;
import org.eclipse.example.smarthomemodel.k3.ActuatorAspectActuatorAspectProperties;
import smarthome.Actuator;

@SuppressWarnings("all")
public class ActuatorAspectActuatorAspectContext {
  public final static ActuatorAspectActuatorAspectContext INSTANCE = new ActuatorAspectActuatorAspectContext();
  
  public static ActuatorAspectActuatorAspectProperties getSelf(final Actuator _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.eclipse.example.smarthomemodel.k3.ActuatorAspectActuatorAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Actuator, ActuatorAspectActuatorAspectProperties> map = new java.util.WeakHashMap<smarthome.Actuator, org.eclipse.example.smarthomemodel.k3.ActuatorAspectActuatorAspectProperties>();
  
  public Map<Actuator, ActuatorAspectActuatorAspectProperties> getMap() {
    return map;
  }
}
