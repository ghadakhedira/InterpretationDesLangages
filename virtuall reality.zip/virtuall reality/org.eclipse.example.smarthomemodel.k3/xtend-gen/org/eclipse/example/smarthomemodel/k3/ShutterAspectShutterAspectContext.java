package org.eclipse.example.smarthomemodel.k3;

import java.util.Map;
import org.eclipse.example.smarthomemodel.k3.ShutterAspectShutterAspectProperties;
import smarthome.Shutter;

@SuppressWarnings("all")
public class ShutterAspectShutterAspectContext {
  public final static ShutterAspectShutterAspectContext INSTANCE = new ShutterAspectShutterAspectContext();
  
  public static ShutterAspectShutterAspectProperties getSelf(final Shutter _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.eclipse.example.smarthomemodel.k3.ShutterAspectShutterAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Shutter, ShutterAspectShutterAspectProperties> map = new java.util.WeakHashMap<smarthome.Shutter, org.eclipse.example.smarthomemodel.k3.ShutterAspectShutterAspectProperties>();
  
  public Map<Shutter, ShutterAspectShutterAspectProperties> getMap() {
    return map;
  }
}
