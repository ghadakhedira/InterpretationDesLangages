package org.eclipse.example.smarthomemodel.k3;

import java.util.Map;
import org.eclipse.example.smarthomemodel.k3.LampAspectLampAspectProperties;
import smarthome.Lamp;

@SuppressWarnings("all")
public class LampAspectLampAspectContext {
  public final static LampAspectLampAspectContext INSTANCE = new LampAspectLampAspectContext();
  
  public static LampAspectLampAspectProperties getSelf(final Lamp _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.eclipse.example.smarthomemodel.k3.LampAspectLampAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Lamp, LampAspectLampAspectProperties> map = new java.util.WeakHashMap<smarthome.Lamp, org.eclipse.example.smarthomemodel.k3.LampAspectLampAspectProperties>();
  
  public Map<Lamp, LampAspectLampAspectProperties> getMap() {
    return map;
  }
}
