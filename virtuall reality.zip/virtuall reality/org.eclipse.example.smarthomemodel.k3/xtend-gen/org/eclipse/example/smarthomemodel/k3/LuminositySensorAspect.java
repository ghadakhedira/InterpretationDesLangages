package org.eclipse.example.smarthomemodel.k3;

import com.google.common.base.Objects;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectProperties;
import smarthome.Luminosity;
import smarthome.LuminositySensor;
import smarthome.Luminosity_Sensor_Type;
import smarthome.OPcomp;
import smarthome.STATE;

@Aspect(className = LuminositySensor.class)
@SuppressWarnings("all")
public class LuminositySensorAspect {
  public static Luminosity Luminosity_value_IN(final LuminositySensor _self) {
    final org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# Luminosity Luminosity_value_IN()
    if (_self instanceof smarthome.LuminositySensor){
    	result = org.eclipse.example.smarthomemodel.k3.LuminositySensorAspect._privk3_Luminosity_value_IN(_self_, (smarthome.LuminositySensor)_self);
    };
    return (smarthome.Luminosity)result;
  }
  
  public static Luminosity Luminosity_value_OUT(final LuminositySensor _self) {
    final org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# Luminosity Luminosity_value_OUT()
    if (_self instanceof smarthome.LuminositySensor){
    	result = org.eclipse.example.smarthomemodel.k3.LuminositySensorAspect._privk3_Luminosity_value_OUT(_self_, (smarthome.LuminositySensor)_self);
    };
    return (smarthome.Luminosity)result;
  }
  
  public static Luminosity WhichState(final LuminositySensor _self) {
    final org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# Luminosity WhichState()
    if (_self instanceof smarthome.LuminositySensor){
    	result = org.eclipse.example.smarthomemodel.k3.LuminositySensorAspect._privk3_WhichState(_self_, (smarthome.LuminositySensor)_self);
    };
    return (smarthome.Luminosity)result;
  }
  
  private static Integer i(final LuminositySensor _self) {
    final org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# Integer i()
    if (_self instanceof smarthome.LuminositySensor){
    	result = org.eclipse.example.smarthomemodel.k3.LuminositySensorAspect._privk3_i(_self_, (smarthome.LuminositySensor)_self);
    };
    return (java.lang.Integer)result;
  }
  
  private static void i(final LuminositySensor _self, final Integer i) {
    final org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void i(Integer)
    if (_self instanceof smarthome.LuminositySensor){
    	org.eclipse.example.smarthomemodel.k3.LuminositySensorAspect._privk3_i(_self_, (smarthome.LuminositySensor)_self,i);
    };
  }
  
  private static String type_sens(final LuminositySensor _self) {
    final org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# String type_sens()
    if (_self instanceof smarthome.LuminositySensor){
    	result = org.eclipse.example.smarthomemodel.k3.LuminositySensorAspect._privk3_type_sens(_self_, (smarthome.LuminositySensor)_self);
    };
    return (java.lang.String)result;
  }
  
  private static void type_sens(final LuminositySensor _self, final String type_sens) {
    final org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void type_sens(String)
    if (_self instanceof smarthome.LuminositySensor){
    	org.eclipse.example.smarthomemodel.k3.LuminositySensorAspect._privk3_type_sens(_self_, (smarthome.LuminositySensor)_self,type_sens);
    };
  }
  
  protected static Luminosity _privk3_Luminosity_value_IN(final LuminositySensorAspectLuminositySensorAspectProperties _self_, final LuminositySensor _self) {
    Luminosity b = Luminosity.HIGH;
    OPcomp _operation = _self.getOperation();
    if (_operation != null) {
      switch (_operation) {
        case EGAL:
          int _value = _self.getState().getValue();
          boolean _equals = Objects.equal(Integer.valueOf(_value), STATE.OPEN);
          if (_equals) {
            Luminosity_Sensor_Type _type_sens = _self.getType_sens();
            boolean _equals_1 = Objects.equal(_type_sens, "In");
            if (_equals_1) {
              return _self.getValue();
            }
          }
          break;
        case DIFF:
          int _value_1 = _self.getState().getValue();
          boolean _equals_2 = Objects.equal(Integer.valueOf(_value_1), STATE.OPEN);
          if (_equals_2) {
            Luminosity_Sensor_Type _type_sens_1 = _self.getType_sens();
            boolean _equals_3 = Objects.equal(_type_sens_1, "Out");
            if (_equals_3) {
              return _self.getValue();
            }
          }
          break;
        default:
          break;
      }
    }
    return null;
  }
  
  protected static Luminosity _privk3_Luminosity_value_OUT(final LuminositySensorAspectLuminositySensorAspectProperties _self_, final LuminositySensor _self) {
    OPcomp _operation = _self.getOperation();
    if (_operation != null) {
      switch (_operation) {
        case DIFF:
          int _value = _self.getState().getValue();
          boolean _equals = Objects.equal(Integer.valueOf(_value), STATE.OPEN);
          if (_equals) {
            Luminosity_Sensor_Type _type_sens = _self.getType_sens();
            boolean _equals_1 = Objects.equal(_type_sens, "Out");
            if (_equals_1) {
              return _self.getValue();
            }
          }
          break;
        default:
          break;
      }
    }
    return null;
  }
  
  protected static Luminosity _privk3_WhichState(final LuminositySensorAspectLuminositySensorAspectProperties _self_, final LuminositySensor _self) {
    int hour = 0;
    Luminosity b = Luminosity.HIGH;
    Luminosity c = Luminosity.LOW;
    while (true) {
      if (((hour < 24) && (hour >= 0))) {
        hour = (hour + 1);
        if (((hour < 8) && (hour > 19))) {
          _self.setValue(b);
          return b;
        }
        if (((hour > 8) && (hour < 19))) {
          _self.setValue(c);
          return c;
        }
      } else {
        hour = 0;
        return null;
      }
    }
  }
  
  protected static Integer _privk3_i(final LuminositySensorAspectLuminositySensorAspectProperties _self_, final LuminositySensor _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getI") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (java.lang.Integer) ret;
    				} else {
    					return null;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.i;
  }
  
  protected static void _privk3_i(final LuminositySensorAspectLuminositySensorAspectProperties _self_, final LuminositySensor _self, final Integer i) {
    boolean setterCalled = false;
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setI")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, i);
    			setterCalled = true;
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    if (!setterCalled) {
    	_self_.i = i;
    }
  }
  
  protected static String _privk3_type_sens(final LuminositySensorAspectLuminositySensorAspectProperties _self_, final LuminositySensor _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getType_sens") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (java.lang.String) ret;
    				} else {
    					return null;
    				}
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.type_sens;
  }
  
  protected static void _privk3_type_sens(final LuminositySensorAspectLuminositySensorAspectProperties _self_, final LuminositySensor _self, final String type_sens) {
    boolean setterCalled = false;
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setType_sens")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, type_sens);
    			setterCalled = true;
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    if (!setterCalled) {
    	_self_.type_sens = type_sens;
    }
  }
}
