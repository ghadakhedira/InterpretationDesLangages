package org.eclipse.example.smarthomemodel.k3;

@SuppressWarnings("all")
public class LuminositySensorAspectLuminositySensorAspectProperties {
  public Integer i = Integer.valueOf(0);
  
  public String type_sens = "in";
}
