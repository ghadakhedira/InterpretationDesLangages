package org.eclipse.example.smarthomemodel.k3;

@SuppressWarnings("all")
public class SmartHomeAspectSmartHomeAspectProperties {
  public int sensor_value = 2;
}
