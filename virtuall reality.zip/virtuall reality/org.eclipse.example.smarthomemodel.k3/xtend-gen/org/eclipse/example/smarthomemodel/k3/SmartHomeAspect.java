package org.eclipse.example.smarthomemodel.k3;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import fr.inria.diverse.k3.al.annotationprocessor.Main;
import org.eclipse.emf.common.util.EList;
import org.eclipse.example.smarthomemodel.k3.SmartHomeAspectSmartHomeAspectProperties;
import smarthome.Luminosity;
import smarthome.Room;
import smarthome.SmartHome;

/**
 * Sample aspect that gives java.io.File the ability to store Text content and save it to disk
 */
@Aspect(className = SmartHome.class)
@SuppressWarnings("all")
public class SmartHomeAspect {
  public static void initialize(final SmartHome _self) {
    final org.eclipse.example.smarthomemodel.k3.SmartHomeAspectSmartHomeAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.SmartHomeAspectSmartHomeAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void initialize()
    if (_self instanceof smarthome.SmartHome){
    	org.eclipse.example.smarthomemodel.k3.SmartHomeAspect._privk3_initialize(_self_, (smarthome.SmartHome)_self);
    };
  }
  
  @Main
  public static void run(final SmartHome _self) {
    final org.eclipse.example.smarthomemodel.k3.SmartHomeAspectSmartHomeAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.SmartHomeAspectSmartHomeAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void run()
    if (_self instanceof smarthome.SmartHome){
    	org.eclipse.example.smarthomemodel.k3.SmartHomeAspect._privk3_run(_self_, (smarthome.SmartHome)_self);
    };
  }
  
  private static int sensor_value(final SmartHome _self) {
    final org.eclipse.example.smarthomemodel.k3.SmartHomeAspectSmartHomeAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.SmartHomeAspectSmartHomeAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# int sensor_value()
    if (_self instanceof smarthome.SmartHome){
    	result = org.eclipse.example.smarthomemodel.k3.SmartHomeAspect._privk3_sensor_value(_self_, (smarthome.SmartHome)_self);
    };
    return (int)result;
  }
  
  private static void sensor_value(final SmartHome _self, final int sensor_value) {
    final org.eclipse.example.smarthomemodel.k3.SmartHomeAspectSmartHomeAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.SmartHomeAspectSmartHomeAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void sensor_value(int)
    if (_self instanceof smarthome.SmartHome){
    	org.eclipse.example.smarthomemodel.k3.SmartHomeAspect._privk3_sensor_value(_self_, (smarthome.SmartHome)_self,sensor_value);
    };
  }
  
  protected static void _privk3_initialize(final SmartHomeAspectSmartHomeAspectProperties _self_, final SmartHome _self) {
    Luminosity a = Luminosity.NORMAL;
    EList<Room> _room = _self.getRoom();
    for (final Room r : _room) {
      {
        r.setRoom_name("bedroom");
        r.getRules().get(1);
      }
    }
  }
  
  protected static void _privk3_run(final SmartHomeAspectSmartHomeAspectProperties _self_, final SmartHome _self) {
    SmartHomeAspect.initialize(_self);
  }
  
  protected static int _privk3_sensor_value(final SmartHomeAspectSmartHomeAspectProperties _self_, final SmartHome _self) {
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("getSensor_value") &&
    			m.getParameterTypes().length == 0) {
    				Object ret = m.invoke(_self);
    				if (ret != null) {
    					return (int) ret;
    				}		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    return _self_.sensor_value;
  }
  
  protected static void _privk3_sensor_value(final SmartHomeAspectSmartHomeAspectProperties _self_, final SmartHome _self, final int sensor_value) {
    boolean setterCalled = false;
    try {
    	for (java.lang.reflect.Method m : _self.getClass().getMethods()) {
    		if (m.getName().equals("setSensor_value")
    				&& m.getParameterTypes().length == 1) {
    			m.invoke(_self, sensor_value);
    			setterCalled = true;
    		}
    	}
    } catch (Exception e) {
    	// Chut !
    }
    if (!setterCalled) {
    	_self_.sensor_value = sensor_value;
    }
  }
}
