package org.eclipse.example.smarthomemodel.k3;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.example.smarthomemodel.k3.LampAspectLampAspectProperties;
import smarthome.Lamp;
import smarthome.STATE;

@Aspect(className = Lamp.class)
@SuppressWarnings("all")
public class LampAspect {
  public static void on_Lamp(final Lamp _self) {
    final org.eclipse.example.smarthomemodel.k3.LampAspectLampAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.LampAspectLampAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void on_Lamp()
    if (_self instanceof smarthome.Lamp){
    	org.eclipse.example.smarthomemodel.k3.LampAspect._privk3_on_Lamp(_self_, (smarthome.Lamp)_self);
    };
  }
  
  public static void off_Lamp(final Lamp _self) {
    final org.eclipse.example.smarthomemodel.k3.LampAspectLampAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.LampAspectLampAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void off_Lamp()
    if (_self instanceof smarthome.Lamp){
    	org.eclipse.example.smarthomemodel.k3.LampAspect._privk3_off_Lamp(_self_, (smarthome.Lamp)_self);
    };
  }
  
  protected static void _privk3_on_Lamp(final LampAspectLampAspectProperties _self_, final Lamp _self) {
    _self.setState_acti_lampe(STATE.OPEN);
  }
  
  protected static void _privk3_off_Lamp(final LampAspectLampAspectProperties _self_, final Lamp _self) {
    _self.setState_acti_lampe(STATE.CLOSE);
  }
}
