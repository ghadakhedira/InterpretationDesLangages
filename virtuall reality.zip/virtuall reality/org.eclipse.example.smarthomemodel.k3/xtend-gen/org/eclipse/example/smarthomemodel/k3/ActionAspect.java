package org.eclipse.example.smarthomemodel.k3;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import javax.swing.Action;

@Aspect(className = Action.class)
@SuppressWarnings("all")
public class ActionAspect {
}
