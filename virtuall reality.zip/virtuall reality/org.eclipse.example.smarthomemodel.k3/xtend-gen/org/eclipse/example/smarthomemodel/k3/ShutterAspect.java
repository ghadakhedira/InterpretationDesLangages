package org.eclipse.example.smarthomemodel.k3;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.example.smarthomemodel.k3.ShutterAspectShutterAspectProperties;
import smarthome.STATE;
import smarthome.Shutter;

@Aspect(className = Shutter.class)
@SuppressWarnings("all")
public class ShutterAspect {
  public static void on_Shutter(final Shutter _self) {
    final org.eclipse.example.smarthomemodel.k3.ShutterAspectShutterAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.ShutterAspectShutterAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void on_Shutter()
    if (_self instanceof smarthome.Shutter){
    	org.eclipse.example.smarthomemodel.k3.ShutterAspect._privk3_on_Shutter(_self_, (smarthome.Shutter)_self);
    };
  }
  
  public static void off_Shutter(final Shutter _self) {
    final org.eclipse.example.smarthomemodel.k3.ShutterAspectShutterAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.ShutterAspectShutterAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void off_Shutter()
    if (_self instanceof smarthome.Shutter){
    	org.eclipse.example.smarthomemodel.k3.ShutterAspect._privk3_off_Shutter(_self_, (smarthome.Shutter)_self);
    };
  }
  
  protected static void _privk3_on_Shutter(final ShutterAspectShutterAspectProperties _self_, final Shutter _self) {
    _self.setState_acti_shutter(STATE.OPEN);
  }
  
  protected static void _privk3_off_Shutter(final ShutterAspectShutterAspectProperties _self_, final Shutter _self) {
    _self.setState_acti_shutter(STATE.CLOSE);
  }
}
