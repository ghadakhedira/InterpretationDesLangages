package org.eclipse.example.smarthomemodel.k3;

@SuppressWarnings("all")
public class ConditionAspectConditionAspectProperties {
}
