package org.eclipse.example.smarthomemodel.k3;

import java.util.Map;
import org.eclipse.example.smarthomemodel.k3.SmartHomeAspectSmartHomeAspectProperties;
import smarthome.SmartHome;

@SuppressWarnings("all")
public class SmartHomeAspectSmartHomeAspectContext {
  public final static SmartHomeAspectSmartHomeAspectContext INSTANCE = new SmartHomeAspectSmartHomeAspectContext();
  
  public static SmartHomeAspectSmartHomeAspectProperties getSelf(final SmartHome _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.eclipse.example.smarthomemodel.k3.SmartHomeAspectSmartHomeAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<SmartHome, SmartHomeAspectSmartHomeAspectProperties> map = new java.util.WeakHashMap<smarthome.SmartHome, org.eclipse.example.smarthomemodel.k3.SmartHomeAspectSmartHomeAspectProperties>();
  
  public Map<SmartHome, SmartHomeAspectSmartHomeAspectProperties> getMap() {
    return map;
  }
}
