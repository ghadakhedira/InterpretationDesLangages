package org.eclipse.example.smarthomemodel.k3;

import java.util.Map;
import org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectProperties;
import smarthome.LuminositySensor;

@SuppressWarnings("all")
public class LuminositySensorAspectLuminositySensorAspectContext {
  public final static LuminositySensorAspectLuminositySensorAspectContext INSTANCE = new LuminositySensorAspectLuminositySensorAspectContext();
  
  public static LuminositySensorAspectLuminositySensorAspectProperties getSelf(final LuminositySensor _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<LuminositySensor, LuminositySensorAspectLuminositySensorAspectProperties> map = new java.util.WeakHashMap<smarthome.LuminositySensor, org.eclipse.example.smarthomemodel.k3.LuminositySensorAspectLuminositySensorAspectProperties>();
  
  public Map<LuminositySensor, LuminositySensorAspectLuminositySensorAspectProperties> getMap() {
    return map;
  }
}
