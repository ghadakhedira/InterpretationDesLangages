package org.eclipse.example.smarthomemodel.k3;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.emf.common.util.EList;
import org.eclipse.example.smarthomemodel.k3.RuleAspectRuleAspectProperties;
import org.eclipse.xtext.xbase.lib.InputOutput;
import smarthome.Condition;
import smarthome.Rule;

@Aspect(className = Rule.class)
@SuppressWarnings("all")
public class RuleAspect {
  public static String result(final Rule _self) {
    final org.eclipse.example.smarthomemodel.k3.RuleAspectRuleAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.RuleAspectRuleAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# String result()
    if (_self instanceof smarthome.Rule){
    	result = org.eclipse.example.smarthomemodel.k3.RuleAspect._privk3_result(_self_, (smarthome.Rule)_self);
    };
    return (java.lang.String)result;
  }
  
  protected static String _privk3_result(final RuleAspectRuleAspectProperties _self_, final Rule _self) {
    EList<Condition> _condition = _self.getCondition();
    for (final Condition c : _condition) {
      {
        boolean _eval = c.eval();
        boolean _equals = (_eval == true);
        if (_equals) {
          InputOutput.<String>println("Open Shutter and close light");
        }
        boolean _eval_1 = c.eval();
        boolean _equals_1 = (_eval_1 == false);
        if (_equals_1) {
          InputOutput.<String>println("Close Shutter and Open light");
        } else {
          InputOutput.<String>println("NO Condition Found");
        }
      }
    }
    return null;
  }
}
