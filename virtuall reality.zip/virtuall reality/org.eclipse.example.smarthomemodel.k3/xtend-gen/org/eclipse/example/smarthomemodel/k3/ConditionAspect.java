package org.eclipse.example.smarthomemodel.k3;

import com.google.common.base.Objects;
import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.emf.common.util.EList;
import org.eclipse.example.smarthomemodel.k3.ConditionAspectConditionAspectProperties;
import smarthome.Condition;
import smarthome.Luminosity;
import smarthome.LuminositySensor;

@Aspect(className = Condition.class)
@SuppressWarnings("all")
public class ConditionAspect {
  public static Boolean eval(final Condition _self) {
    final org.eclipse.example.smarthomemodel.k3.ConditionAspectConditionAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.ConditionAspectConditionAspectContext.getSelf(_self);
    Object result = null;
    // #DispatchPointCut_before# Boolean eval()
    if (_self instanceof smarthome.Condition){
    	result = org.eclipse.example.smarthomemodel.k3.ConditionAspect._privk3_eval(_self_, (smarthome.Condition)_self);
    };
    return (java.lang.Boolean)result;
  }
  
  protected static Boolean _privk3_eval(final ConditionAspectConditionAspectProperties _self_, final Condition _self) {
    EList<LuminositySensor> _luminositysensor = _self.getLuminositysensor();
    for (final LuminositySensor l : _luminositysensor) {
      {
        if (((Objects.equal(l.Luminosity_value_OUT(), Luminosity.HIGH) && Objects.equal(l.Luminosity_value_IN(), Luminosity.HIGH)) && Objects.equal(l.WhichState(), Luminosity.HIGH))) {
          return Boolean.valueOf(true);
        }
        if (((Objects.equal(l.Luminosity_value_OUT(), Luminosity.LOW) && Objects.equal(l.Luminosity_value_IN(), Luminosity.LOW)) && Objects.equal(l.WhichState(), Luminosity.LOW))) {
          return Boolean.valueOf(false);
        }
      }
    }
    return null;
  }
}
