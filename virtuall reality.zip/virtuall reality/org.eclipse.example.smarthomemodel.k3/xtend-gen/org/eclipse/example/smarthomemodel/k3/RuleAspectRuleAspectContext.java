package org.eclipse.example.smarthomemodel.k3;

import java.util.Map;
import org.eclipse.example.smarthomemodel.k3.RuleAspectRuleAspectProperties;
import smarthome.Rule;

@SuppressWarnings("all")
public class RuleAspectRuleAspectContext {
  public final static RuleAspectRuleAspectContext INSTANCE = new RuleAspectRuleAspectContext();
  
  public static RuleAspectRuleAspectProperties getSelf(final Rule _self) {
    		if (!INSTANCE.map.containsKey(_self))
    			INSTANCE.map.put(_self, new org.eclipse.example.smarthomemodel.k3.RuleAspectRuleAspectProperties());
    		return INSTANCE.map.get(_self);
  }
  
  private Map<Rule, RuleAspectRuleAspectProperties> map = new java.util.WeakHashMap<smarthome.Rule, org.eclipse.example.smarthomemodel.k3.RuleAspectRuleAspectProperties>();
  
  public Map<Rule, RuleAspectRuleAspectProperties> getMap() {
    return map;
  }
}
