package org.eclipse.example.smarthomemodel.k3;

import fr.inria.diverse.k3.al.annotationprocessor.Aspect;
import org.eclipse.emf.common.util.EList;
import org.eclipse.example.smarthomemodel.k3.ActuatorAspectActuatorAspectProperties;
import org.eclipse.example.smarthomemodel.k3.LampAspect;
import org.eclipse.example.smarthomemodel.k3.ShutterAspect;
import smarthome.Actuator;
import smarthome.Rule;

@Aspect(className = Actuator.class)
@SuppressWarnings("all")
public class ActuatorAspect {
  public static void state_acti_shutter(final Actuator _self) {
    final org.eclipse.example.smarthomemodel.k3.ActuatorAspectActuatorAspectProperties _self_ = org.eclipse.example.smarthomemodel.k3.ActuatorAspectActuatorAspectContext.getSelf(_self);
    // #DispatchPointCut_before# void state_acti_shutter()
    if (_self instanceof smarthome.Actuator){
    	org.eclipse.example.smarthomemodel.k3.ActuatorAspect._privk3_state_acti_shutter(_self_, (smarthome.Actuator)_self);
    };
  }
  
  protected static void _privk3_state_acti_shutter(final ActuatorAspectActuatorAspectProperties _self_, final Actuator _self) {
    EList<Rule> _rule = _self.getRule();
    for (final Rule rule : _rule) {
      {
        boolean _equals = rule.result().equals("Open Shutter and close light");
        if (_equals) {
          ShutterAspect.on_Shutter(null);
          LampAspect.off_Lamp(null);
        }
        boolean _equals_1 = rule.result().equals("Close Shutter and Open light");
        if (_equals_1) {
          ShutterAspect.off_Shutter(null);
          LampAspect.on_Lamp(null);
        }
      }
    }
  }
}
